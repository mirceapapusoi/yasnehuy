from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.postgresql import JSON

# Инициализация SQLAlchemy
db = SQLAlchemy()

class User(db.Model):
    """Модель пользователя Telegram."""
    __tablename__ = "users"
    
    id = db.Column(db.BigInteger, primary_key=True)
    username = db.Column(db.String(128), nullable=True)
    first_name = db.Column(db.String(256), nullable=False)
    last_name = db.Column(db.String(256), nullable=True)
    language_code = db.Column(db.String(10), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    is_banned = db.Column(db.Boolean, default=False)
    messages_count = db.Column(db.Integer, default=0)
    commands_count = db.Column(db.Integer, default=0)
    bot_rating = db.Column(db.Integer, nullable=True)
    feedback_text = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи с другими таблицами
    chat_users = db.relationship("ChatUser", back_populates="user", cascade="all, delete-orphan")
    messages = db.relationship("Message", back_populates="user", cascade="all, delete-orphan")
    relationship_from = db.relationship("Relationship", foreign_keys="Relationship.from_user_id", 
                                    back_populates="from_user", cascade="all, delete-orphan")
    relationship_to = db.relationship("Relationship", foreign_keys="Relationship.to_user_id", 
                                  back_populates="to_user", cascade="all, delete-orphan")
    commands = db.relationship("CommandStat", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User {self.id} @{self.username}>"


class Chat(db.Model):
    """Модель чата Telegram."""
    __tablename__ = "chats"
    
    id = db.Column(db.BigInteger, primary_key=True)
    title = db.Column(db.String(256), nullable=True)
    type = db.Column(db.String(32), nullable=False)
    username = db.Column(db.String(128), nullable=True)
    messages_count = db.Column(db.Integer, default=0)
    commands_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи с другими таблицами
    chat_users = db.relationship("ChatUser", back_populates="chat", cascade="all, delete-orphan")
    messages = db.relationship("Message", back_populates="chat", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Chat {self.id} {self.title}>"


class ChatUser(db.Model):
    """Модель связи пользователя с чатом."""
    __tablename__ = "chat_users"
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    chat_id = db.Column(db.BigInteger, db.ForeignKey("chats.id"), nullable=False)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Связи с другими таблицами
    user = db.relationship("User", back_populates="chat_users")
    chat = db.relationship("Chat", back_populates="chat_users")
    
    def __repr__(self):
        return f"<ChatUser {self.user_id} in {self.chat_id}>"


class Message(db.Model):
    """Модель сообщения."""
    __tablename__ = "messages"
    
    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.BigInteger, nullable=False)
    user_id = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    chat_id = db.Column(db.BigInteger, db.ForeignKey("chats.id"), nullable=False)
    text = db.Column(db.Text, nullable=True)
    is_command = db.Column(db.Boolean, default=False)
    sentiment = db.Column(db.String(32), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Связи с другими таблицами
    user = db.relationship("User", back_populates="messages")
    chat = db.relationship("Chat", back_populates="messages")
    
    def __repr__(self):
        return f"<Message {self.id} from {self.user_id}>"


class CommandStat(db.Model):
    """Модель статистики использования команд."""
    __tablename__ = "command_stats"
    
    id = db.Column(db.Integer, primary_key=True)
    command_name = db.Column(db.String(64), nullable=False)
    user_id = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    count = db.Column(db.Integer, default=1)
    last_used = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Связи с другими таблицами
    user = db.relationship("User", back_populates="commands")
    
    __table_args__ = (
        db.UniqueConstraint('command_name', 'user_id', name='uix_command_user'),
    )
    
    def __repr__(self):
        return f"<CommandStat {self.command_name} by {self.user_id}>"


class Relationship(db.Model):
    """Модель отношений между пользователями."""
    __tablename__ = "relationships"
    
    id = db.Column(db.Integer, primary_key=True)
    from_user_id = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    to_user_id = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    chat_id = db.Column(db.BigInteger, nullable=False)
    status = db.Column(db.String(32), nullable=False)  # pending, active, broken
    level = db.Column(db.Integer, default=1)
    experience = db.Column(db.Integer, default=0)
    is_offended = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    activated_at = db.Column(db.DateTime, nullable=True)
    last_action_at = db.Column(db.DateTime, default=datetime.utcnow)
    actions_history = db.Column(JSON, default=dict)
    
    # Связи с другими таблицами
    from_user = db.relationship("User", foreign_keys=[from_user_id], back_populates="relationship_from")
    to_user = db.relationship("User", foreign_keys=[to_user_id], back_populates="relationship_to")
    
    __table_args__ = (
        db.CheckConstraint('from_user_id != to_user_id', name='check_different_users'),
    )
    
    def __repr__(self):
        return f"<Relationship {self.from_user_id} -> {self.to_user_id} ({self.status})>"


class ActivityStat(db.Model):
    """Модель статистики активности бота."""
    __tablename__ = "activity_stats"
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    hour = db.Column(db.Integer, nullable=True)
    messages_count = db.Column(db.Integer, default=0)
    commands_count = db.Column(db.Integer, default=0)
    unique_users = db.Column(db.Integer, default=0)
    unique_chats = db.Column(db.Integer, default=0)
    cpu_usage = db.Column(db.Float, default=0)
    memory_usage = db.Column(db.Float, default=0)
    errors_count = db.Column(db.Integer, default=0)
    
    __table_args__ = (
        db.UniqueConstraint('date', 'hour', name='uix_date_hour'),
    )
    
    def __repr__(self):
        if self.hour is not None:
            return f"<ActivityStat {self.date} {self.hour}:00>"
        return f"<ActivityStat {self.date}>"