"""
Модуль для мониторинга и аналитики использования бота.
Предоставляет функции для сбора и отображения статистики.
"""

import os
import time
import json
import logging
import datetime
import psutil
from collections import defaultdict, Counter

logger = logging.getLogger(__name__)

# Файл для хранения данных мониторинга
MONITORING_FILE = "data/monitoring.json"

# Файл для хранения статистики использования команд
COMMANDS_STATS_FILE = "data/commands_stats.json"

# Базовая структура для мониторинга
DEFAULT_MONITORING_DATA = {
    "start_time": None,
    "commands_executed": 0,
    "messages_processed": 0,
    "users_count": 0,
    "chats_count": 0,
    "errors_count": 0,
    "last_updated": None,
    "peak_memory_usage": 0,
    "peak_cpu_usage": 0,
    "daily_stats": {},
    "hourly_stats": {}
}

def ensure_monitoring_files():
    """Проверяет наличие файлов мониторинга и создает их при необходимости."""
    os.makedirs("data", exist_ok=True)
    
    # Создаем файл мониторинга, если не существует
    if not os.path.exists(MONITORING_FILE):
        with open(MONITORING_FILE, "w", encoding="utf-8") as f:
            monitoring_data = DEFAULT_MONITORING_DATA.copy()
            monitoring_data["start_time"] = datetime.datetime.now().isoformat()
            monitoring_data["last_updated"] = datetime.datetime.now().isoformat()
            json.dump(monitoring_data, f, ensure_ascii=False, indent=2)
    
    # Создаем файл статистики команд, если не существует
    if not os.path.exists(COMMANDS_STATS_FILE):
        with open(COMMANDS_STATS_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f, ensure_ascii=False, indent=2)

def load_monitoring_data():
    """Загружает данные мониторинга из файла."""
    ensure_monitoring_files()
    try:
        with open(MONITORING_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Ошибка при загрузке данных мониторинга: {e}")
        return DEFAULT_MONITORING_DATA.copy()

def save_monitoring_data(data):
    """Сохраняет данные мониторинга в файл."""
    ensure_monitoring_files()
    try:
        with open(MONITORING_FILE, "w", encoding="utf-8") as f:
            data["last_updated"] = datetime.datetime.now().isoformat()
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Ошибка при сохранении данных мониторинга: {e}")

def track_message(user_id, chat_id, is_command=False):
    """
    Отслеживает обработку сообщения и обновляет статистику.
    
    Args:
        user_id (int): ID пользователя
        chat_id (int): ID чата
        is_command (bool): Является ли сообщение командой
    """
    data = load_monitoring_data()
    
    # Увеличиваем счетчики
    data["messages_processed"] += 1
    if is_command:
        data["commands_executed"] += 1
    
    # Обновляем статистику по дням и часам
    now = datetime.datetime.now()
    day_key = now.strftime("%Y-%m-%d")
    hour_key = now.strftime("%Y-%m-%d-%H")
    
    # Создаем структуру, если не существует
    if day_key not in data["daily_stats"]:
        data["daily_stats"][day_key] = {
            "messages": 0,
            "commands": 0,
            "users": [],
            "chats": []
        }
    
    if hour_key not in data["hourly_stats"]:
        data["hourly_stats"][hour_key] = {
            "messages": 0,
            "commands": 0,
            "users": [],
            "chats": []
        }
    
    # Обновляем счетчики в статистике
    data["daily_stats"][day_key]["messages"] += 1
    data["hourly_stats"][hour_key]["messages"] += 1
    
    if is_command:
        data["daily_stats"][day_key]["commands"] += 1
        data["hourly_stats"][hour_key]["commands"] += 1
    
    # Для работы с данными в JSON обеспечиваем, что поля всегда будут списками
    if "users" not in data["daily_stats"][day_key] or not isinstance(data["daily_stats"][day_key]["users"], list):
        data["daily_stats"][day_key]["users"] = []
    if "chats" not in data["daily_stats"][day_key] or not isinstance(data["daily_stats"][day_key]["chats"], list):
        data["daily_stats"][day_key]["chats"] = []
    if "users" not in data["hourly_stats"][hour_key] or not isinstance(data["hourly_stats"][hour_key]["users"], list):
        data["hourly_stats"][hour_key]["users"] = []
    if "chats" not in data["hourly_stats"][hour_key] or not isinstance(data["hourly_stats"][hour_key]["chats"], list):
        data["hourly_stats"][hour_key]["chats"] = []
    
    # Добавляем пользователя и чат в списки, если их там нет
    if str(user_id) not in data["daily_stats"][day_key]["users"]:
        data["daily_stats"][day_key]["users"].append(str(user_id))
    if str(chat_id) not in data["daily_stats"][day_key]["chats"]:
        data["daily_stats"][day_key]["chats"].append(str(chat_id))
    
    if str(user_id) not in data["hourly_stats"][hour_key]["users"]:
        data["hourly_stats"][hour_key]["users"].append(str(user_id))
    if str(chat_id) not in data["hourly_stats"][hour_key]["chats"]:
        data["hourly_stats"][hour_key]["chats"].append(str(chat_id))
    
    # Обновляем общую статистику
    unique_users = set()
    unique_chats = set()
    
    for day_data in data["daily_stats"].values():
        if isinstance(day_data["users"], list):
            unique_users.update(day_data["users"])
        elif isinstance(day_data["users"], set):
            # Для совместимости со старыми данными
            unique_users.update(list(day_data["users"]))
            
        if isinstance(day_data["chats"], list):
            unique_chats.update(day_data["chats"])
        elif isinstance(day_data["chats"], set):
            # Для совместимости со старыми данными
            unique_chats.update(list(day_data["chats"]))
    
    data["users_count"] = len(unique_users)
    data["chats_count"] = len(unique_chats)
    
    # Обновляем данные о ресурсах
    process = psutil.Process(os.getpid())
    current_memory = process.memory_info().rss / (1024 * 1024)  # В МБ
    current_cpu = process.cpu_percent()
    
    if current_memory > data.get("peak_memory_usage", 0):
        data["peak_memory_usage"] = current_memory
    
    if current_cpu > data.get("peak_cpu_usage", 0):
        data["peak_cpu_usage"] = current_cpu
    
    save_monitoring_data(data)

def track_command(command_name, user_id):
    """
    Отслеживает выполнение команды и обновляет статистику команд.
    
    Args:
        command_name (str): Имя команды
        user_id (int): ID пользователя
    """
    ensure_monitoring_files()
    
    try:
        with open(COMMANDS_STATS_FILE, "r", encoding="utf-8") as f:
            command_stats = json.load(f)
    except Exception:
        command_stats = {}
    
    if command_name not in command_stats:
        command_stats[command_name] = {
            "count": 0,
            "users": [],
            "last_used": None
        }
    
    command_stats[command_name]["count"] += 1
    command_stats[command_name]["last_used"] = datetime.datetime.now().isoformat()
    
    if str(user_id) not in command_stats[command_name]["users"]:
        command_stats[command_name]["users"].append(str(user_id))
    
    try:
        with open(COMMANDS_STATS_FILE, "w", encoding="utf-8") as f:
            json.dump(command_stats, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Ошибка при сохранении статистики команд: {e}")

def track_error(error_type):
    """
    Отслеживает ошибку и обновляет статистику.
    
    Args:
        error_type (str): Тип ошибки
    """
    data = load_monitoring_data()
    data["errors_count"] += 1
    save_monitoring_data(data)

def get_system_stats():
    """
    Возвращает текущую статистику использования системных ресурсов.
    
    Returns:
        dict: Словарь со статистикой использования системных ресурсов
    """
    process = psutil.Process(os.getpid())
    
    # Использование CPU
    cpu_percent = process.cpu_percent(interval=0.5)
    
    # Использование памяти
    memory_info = process.memory_info()
    memory_usage_mb = memory_info.rss / (1024 * 1024)  # Переводим байты в мегабайты
    
    # Количество потоков и дескрипторов файлов
    threads_count = process.num_threads()
    
    # Время работы бота
    start_time = process.create_time()
    uptime_seconds = time.time() - start_time
    
    # Информация о системе
    system_memory = psutil.virtual_memory()
    system_cpu = psutil.cpu_percent(interval=None)
    
    return {
        "cpu_percent": cpu_percent,
        "system_cpu_percent": system_cpu,
        "memory_usage_mb": round(memory_usage_mb, 2),
        "system_memory_percent": system_memory.percent,
        "system_memory_total_gb": round(system_memory.total / (1024**3), 2),
        "system_memory_available_gb": round(system_memory.available / (1024**3), 2),
        "threads_count": threads_count,
        "uptime_seconds": uptime_seconds
    }

def get_activity_stats():
    """
    Возвращает статистику активности бота.
    
    Returns:
        dict: Словарь со статистикой активности
    """
    data = load_monitoring_data()
    
    # Загружаем статистику команд
    try:
        with open(COMMANDS_STATS_FILE, "r", encoding="utf-8") as f:
            command_stats = json.load(f)
    except Exception:
        command_stats = {}
    
    # Получаем топ-5 самых используемых команд
    top_commands = sorted(
        command_stats.items(),
        key=lambda x: x[1]["count"],
        reverse=True
    )[:5]
    
    # Статистика за последние 24 часа
    now = datetime.datetime.now()
    day_key = now.strftime("%Y-%m-%d")
    
    messages_today = data["daily_stats"].get(day_key, {}).get("messages", 0)
    commands_today = data["daily_stats"].get(day_key, {}).get("commands", 0)
    users_today = len(data["daily_stats"].get(day_key, {}).get("users", []))
    
    # Форматируем время работы
    start_time = datetime.datetime.fromisoformat(data["start_time"]) if data["start_time"] else datetime.datetime.now()
    uptime = now - start_time
    uptime_days = uptime.days
    uptime_hours, remainder = divmod(uptime.seconds, 3600)
    uptime_minutes, uptime_seconds = divmod(remainder, 60)
    
    return {
        "messages_processed": data["messages_processed"],
        "commands_executed": data["commands_executed"],
        "users_count": data["users_count"],
        "chats_count": data["chats_count"],
        "errors_count": data["errors_count"],
        "peak_memory_usage": round(data.get("peak_memory_usage", 0), 2),
        "peak_cpu_usage": round(data.get("peak_cpu_usage", 0), 2),
        "start_time": data["start_time"],
        "uptime": {
            "days": uptime_days,
            "hours": uptime_hours,
            "minutes": uptime_minutes,
            "seconds": uptime_seconds
        },
        "today_stats": {
            "messages": messages_today,
            "commands": commands_today,
            "users": users_today
        },
        "top_commands": top_commands
    }

def format_activity_text():
    """
    Форматирует текст со статистикой активности.
    
    Returns:
        str: Отформатированный текст со статистикой
    """
    try:
        system_stats = get_system_stats()
        activity_stats = get_activity_stats()
        
        uptime = activity_stats["uptime"]
        uptime_str = f"{uptime['days']}д {uptime['hours']}ч {uptime['minutes']}м {uptime['seconds']}с"
        
        text = f"""📊 **Статистика активности бота**

⏱️ *Время работы:* {uptime_str}
📱 *Всего пользователей:* {activity_stats["users_count"]}
💬 *Всего чатов:* {activity_stats["chats_count"]}
📨 *Обработано сообщений:* {activity_stats["messages_processed"]}
🔍 *Выполнено команд:* {activity_stats["commands_executed"]}
⚠️ *Ошибок:* {activity_stats["errors_count"]}

📈 *Сегодня:*
 • Сообщений: {activity_stats["today_stats"]["messages"]}
 • Команд: {activity_stats["today_stats"]["commands"]}
 • Активных пользователей: {activity_stats["today_stats"]["users"]}

🛠️ *Использование ресурсов:*
 • CPU: {system_stats["cpu_percent"]}% (системный: {system_stats["system_cpu_percent"]}%)
 • RAM: {system_stats["memory_usage_mb"]} MB
 • Системная память: {system_stats["system_memory_percent"]}% 
   ({system_stats["system_memory_available_gb"]} ГБ свободно из {system_stats["system_memory_total_gb"]} ГБ)
 • Потоков: {system_stats["threads_count"]}
 • Пиковое использование CPU: {activity_stats["peak_cpu_usage"]}%
 • Пиковое использование RAM: {activity_stats["peak_memory_usage"]} MB"""
        
        # Добавляем топ команд, если они есть
        if activity_stats["top_commands"]:
            text += "\n\n📝 *Популярные команды:*"
            for i, (cmd, stats) in enumerate(activity_stats["top_commands"], 1):
                text += f"\n {i}. {cmd}: {stats['count']} раз"
        
        return text
    except Exception as e:
        logger.error(f"Ошибка при форматировании статистики: {e}")
        return f"""📊 **Статистика активности бота**

⚠️ *Не удалось получить полную статистику*

Доступные системные ресурсы:
 • CPU: {psutil.cpu_percent()}%
 • Память: {psutil.virtual_memory().percent}%
 • Загрузка системы: {" ".join(str(x) for x in psutil.getloadavg())}

Время работы сервера: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""

# Этот код не используется для текстовой статистики, которая работает независимо от БД