import re
import logging

logger = logging.getLogger(__name__)

def detect_intent(message):
    """
    Detect the user's intent based on the message content.
    This is a basic intent detection that supports both English and Russian.
    
    Args:
        message (str): The user's message
        
    Returns:
        str: The detected intent
    """
    message = message.lower()
    
    # Define patterns for each intent - both English and Russian
    greeting_patterns = [
        # English
        r"hi\b", r"hello\b", r"hey\b", r"howdy\b", r"greetings", 
        r"good morning", r"good afternoon", r"good evening", r"hola",
        # Russian
        r"привет", r"здравствуй", r"здравствуйте", r"доброе утро", 
        r"добрый день", r"добрый вечер", r"здорово", r"приветствую"
    ]
    
    farewell_patterns = [
        # English
        r"bye\b", r"goodbye\b", r"see you", r"farewell", r"cya", 
        r"take care", r"later", r"until next time",
        # Russian
        r"пока", r"до свидания", r"до встречи", r"прощай", 
        r"увидимся", r"бывай", r"счастливо", r"до скорого"
    ]
    
    thanks_patterns = [
        # English
        r"thanks", r"thank you", r"thx", r"appreciate", r"grateful",
        # Russian
        r"спасибо", r"благодарю", r"признателен", r"ценю", r"спс"
    ]
    
    help_patterns = [
        # English
        r"help", r"assist", r"support", r"guide", r"how (can|do) (i|you|we)",
        # Russian
        r"помощь", r"помоги", r"поддержка", r"как (можно|мне|я могу)", 
        r"что (делать|ты умеешь)", r"справка", r"инструкция"
    ]
    
    # Check each pattern against the message
    for pattern in greeting_patterns:
        if re.search(pattern, message):
            return "greeting"
    
    for pattern in farewell_patterns:
        if re.search(pattern, message):
            return "farewell"
    
    for pattern in thanks_patterns:
        if re.search(pattern, message):
            return "thanks"
    
    for pattern in help_patterns:
        if re.search(pattern, message):
            return "help"
    
    # Default intent
    return "unknown"
