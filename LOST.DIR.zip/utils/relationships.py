"""
Модуль для управления отношениями между пользователями.
Позволяет создавать, редактировать и удалять отношения.
"""

import json
import os
import logging
from datetime import datetime
from config import DATA_DIR

logger = logging.getLogger(__name__)

# Путь к файлу с данными об отношениях
RELATIONSHIPS_FILE = os.path.join(DATA_DIR, "relationships.json")

def load_relationships():
    """Загрузка данных об отношениях."""
    try:
        if os.path.exists(RELATIONSHIPS_FILE):
            with open(RELATIONSHIPS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # Если файл не существует, создаем пустой словарь
            return {}
    except Exception as e:
        logger.error(f"Ошибка при загрузке данных об отношениях: {e}")
        return {}

def save_relationships(relationships_data):
    """Сохранение данных об отношениях."""
    try:
        with open(RELATIONSHIPS_FILE, 'w', encoding='utf-8') as f:
            json.dump(relationships_data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        logger.error(f"Ошибка при сохранении данных об отношениях: {e}")

def create_relationship_request(from_user_id, to_user_id, from_username, to_username, chat_id):
    """
    Создает запрос на отношения.
    
    Args:
        from_user_id (str): ID отправителя запроса
        to_user_id (str): ID получателя запроса
        from_username (str): Имя пользователя отправителя
        to_username (str): Имя пользователя получателя
        chat_id (str): ID чата, в котором был создан запрос
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    from_user_id = str(from_user_id)
    to_user_id = str(to_user_id)
    chat_id = str(chat_id)
    
    # Проверяем, есть ли уже отношения у отправителя
    if from_user_id in relationships and relationships[from_user_id].get("partner_id"):
        partner_id = relationships[from_user_id]["partner_id"]
        partner_username = relationships[from_user_id]["partner_username"]
        return (False, f"У вас уже есть отношения с @{partner_username}. Используйте '.отн расторгнуть' для разрыва текущих отношений.")
    
    # Проверяем, есть ли уже отношения у получателя
    if to_user_id in relationships and relationships[to_user_id].get("partner_id"):
        partner_id = relationships[to_user_id]["partner_id"]
        partner_username = relationships[to_user_id]["partner_username"]
        return (False, f"У @{to_username} уже есть отношения с @{partner_username}.")
    
    # Проверяем, есть ли уже запрос от данного пользователя к этому получателю
    if from_user_id in relationships and "requests_sent" in relationships[from_user_id]:
        if to_user_id in relationships[from_user_id]["requests_sent"]:
            return (False, f"Вы уже отправили запрос на отношения пользователю @{to_username}. Дождитесь ответа.")
    
    # Проверяем, есть ли уже запрос от этого получателя к данному пользователю
    if to_user_id in relationships and "requests_sent" in relationships[to_user_id]:
        if from_user_id in relationships[to_user_id]["requests_sent"]:
            # Автоматически принимаем запрос, так как обе стороны хотят отношений
            return accept_relationship_request(to_user_id, from_user_id, to_username, from_username, chat_id)
    
    # Создаем запись для отправителя, если ее еще нет
    if from_user_id not in relationships:
        relationships[from_user_id] = {
            "username": from_username,
            "partner_id": None,
            "partner_username": None,
            "requests_sent": {},
            "requests_received": {},
            "relationships_history": [],
            "is_offended": False,
            "stats": {
                "total_relationships": 0,
                "total_days_in_relationships": 0,
                "loyalty_score": 100,
                "relationship_level": 1,
                "sparks": 0,
                "actions_performed": {}
            }
        }
    
    # Создаем запись для получателя, если ее еще нет
    if to_user_id not in relationships:
        relationships[to_user_id] = {
            "username": to_username,
            "partner_id": None,
            "partner_username": None,
            "requests_sent": {},
            "requests_received": {},
            "relationships_history": [],
            "is_offended": False,
            "stats": {
                "total_relationships": 0,
                "total_days_in_relationships": 0,
                "loyalty_score": 100,
                "relationship_level": 1,
                "sparks": 0,
                "actions_performed": {}
            }
        }
    
    # Создаем запись о запросе
    request_time = datetime.now().isoformat()
    
    # Добавляем запрос в список отправленных для отправителя
    if "requests_sent" not in relationships[from_user_id]:
        relationships[from_user_id]["requests_sent"] = {}
    
    relationships[from_user_id]["requests_sent"][to_user_id] = {
        "username": to_username,
        "time": request_time,
        "chat_id": chat_id
    }
    
    # Добавляем запрос в список полученных для получателя
    if "requests_received" not in relationships[to_user_id]:
        relationships[to_user_id]["requests_received"] = {}
    
    relationships[to_user_id]["requests_received"][from_user_id] = {
        "username": from_username,
        "time": request_time,
        "chat_id": chat_id
    }
    
    save_relationships(relationships)
    
    return (True, f"Запрос на отношения отправлен пользователю @{to_username}. Ожидайте ответа.")

def accept_relationship_request(from_user_id, to_user_id, from_username, to_username, chat_id):
    """
    Принимает запрос на отношения.
    
    Args:
        from_user_id (str): ID отправителя запроса
        to_user_id (str): ID получателя запроса
        from_username (str): Имя пользователя отправителя
        to_username (str): Имя пользователя получателя
        chat_id (str): ID чата, в котором был принят запрос
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    from_user_id = str(from_user_id)
    to_user_id = str(to_user_id)
    chat_id = str(chat_id)
    
    # Проверяем, существует ли запрос
    if (from_user_id not in relationships or 
        "requests_sent" not in relationships[from_user_id] or 
        to_user_id not in relationships[from_user_id]["requests_sent"]):
        return (False, f"Запрос на отношения от @{from_username} не найден.")
    
    # Проверяем, не занят ли уже отправитель или получатель
    if from_user_id in relationships and relationships[from_user_id].get("partner_id"):
        partner_id = relationships[from_user_id]["partner_id"]
        partner_username = relationships[from_user_id]["partner_username"]
        return (False, f"У @{from_username} уже есть отношения с @{partner_username}.")
    
    if to_user_id in relationships and relationships[to_user_id].get("partner_id"):
        partner_id = relationships[to_user_id]["partner_id"]
        partner_username = relationships[to_user_id]["partner_username"]
        return (False, f"У вас уже есть отношения с @{partner_username}. Используйте '.отн расторгнуть' для разрыва текущих отношений.")
    
    # Устанавливаем отношения
    relationship_time = datetime.now().isoformat()
    
    # Обновляем данные отправителя
    relationships[from_user_id]["partner_id"] = to_user_id
    relationships[from_user_id]["partner_username"] = to_username
    relationships[from_user_id]["relationships_history"].append({
        "partner_id": to_user_id,
        "partner_username": to_username,
        "start_time": relationship_time,
        "end_time": None,
        "status": "active"
    })
    relationships[from_user_id]["stats"]["total_relationships"] += 1
    
    # Удаляем запрос из списка отправленных
    if to_user_id in relationships[from_user_id]["requests_sent"]:
        del relationships[from_user_id]["requests_sent"][to_user_id]
    
    # Обновляем данные получателя
    relationships[to_user_id]["partner_id"] = from_user_id
    relationships[to_user_id]["partner_username"] = from_username
    relationships[to_user_id]["relationships_history"].append({
        "partner_id": from_user_id,
        "partner_username": from_username,
        "start_time": relationship_time,
        "end_time": None,
        "status": "active"
    })
    relationships[to_user_id]["stats"]["total_relationships"] += 1
    
    # Удаляем запрос из списка полученных
    if from_user_id in relationships[to_user_id]["requests_received"]:
        del relationships[to_user_id]["requests_received"][from_user_id]
    
    save_relationships(relationships)
    
    return (True, f"Поздравляем! Теперь @{from_username} и @{to_username} состоят в отношениях! 💖")

def reject_relationship_request(from_user_id, to_user_id):
    """
    Отклоняет запрос на отношения.
    
    Args:
        from_user_id (str): ID отправителя запроса
        to_user_id (str): ID получателя запроса
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    from_user_id = str(from_user_id)
    to_user_id = str(to_user_id)
    
    # Проверяем, существует ли запрос
    if (from_user_id not in relationships or 
        "requests_sent" not in relationships[from_user_id] or 
        to_user_id not in relationships[from_user_id]["requests_sent"]):
        return (False, "Запрос на отношения не найден.")
    
    # Получаем имена пользователей
    from_username = relationships[from_user_id]["username"]
    to_username = relationships[to_user_id]["username"]
    
    # Удаляем запрос из списка отправленных
    if to_user_id in relationships[from_user_id]["requests_sent"]:
        del relationships[from_user_id]["requests_sent"][to_user_id]
    
    # Удаляем запрос из списка полученных
    if from_user_id in relationships[to_user_id]["requests_received"]:
        del relationships[to_user_id]["requests_received"][from_user_id]
    
    save_relationships(relationships)
    
    return (True, f"@{to_username} отклонил(а) запрос на отношения от @{from_username}.")

def cancel_relationship_request(from_user_id, to_user_id):
    """
    Отменяет отправленный запрос на отношения.
    
    Args:
        from_user_id (str): ID отправителя запроса
        to_user_id (str): ID получателя запроса
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    from_user_id = str(from_user_id)
    to_user_id = str(to_user_id)
    
    # Проверяем, существует ли запрос
    if (from_user_id not in relationships or 
        "requests_sent" not in relationships[from_user_id] or 
        to_user_id not in relationships[from_user_id]["requests_sent"]):
        return (False, "У вас нет активных запросов на отношения с этим пользователем.")
    
    # Получаем имя получателя
    to_username = relationships[to_user_id]["username"]
    
    # Удаляем запрос из списка отправленных
    if to_user_id in relationships[from_user_id]["requests_sent"]:
        del relationships[from_user_id]["requests_sent"][to_user_id]
    
    # Удаляем запрос из списка полученных
    if from_user_id in relationships[to_user_id]["requests_received"]:
        del relationships[to_user_id]["requests_received"][from_user_id]
    
    save_relationships(relationships)
    
    return (True, f"Запрос на отношения с @{to_username} отменен.")

def break_relationship(user_id):
    """
    Разрывает текущие отношения пользователя.
    
    Args:
        user_id (str): ID пользователя, который хочет разорвать отношения
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    user_id = str(user_id)
    
    # Проверяем, состоит ли пользователь в отношениях
    if user_id not in relationships or not relationships[user_id].get("partner_id"):
        return (False, "Вы не состоите в отношениях.")
    
    # Получаем данные о партнере
    partner_id = relationships[user_id]["partner_id"]
    partner_username = relationships[user_id]["partner_username"]
    
    if partner_id not in relationships:
        # Ошибка в данных, исправляем
        relationships[user_id]["partner_id"] = None
        relationships[user_id]["partner_username"] = None
        save_relationships(relationships)
        return (False, "Ошибка в данных об отношениях. Отношения сброшены.")
    
    # Обновляем данные в истории отношений пользователя
    for rel in relationships[user_id]["relationships_history"]:
        if rel["partner_id"] == partner_id and rel["status"] == "active":
            rel["end_time"] = datetime.now().isoformat()
            rel["status"] = "broken"
            break
    
    # Обновляем данные в истории отношений партнера
    for rel in relationships[partner_id]["relationships_history"]:
        if rel["partner_id"] == user_id and rel["status"] == "active":
            rel["end_time"] = datetime.now().isoformat()
            rel["status"] = "broken"
            break
    
    # Сбрасываем данные об отношениях пользователя
    relationships[user_id]["partner_id"] = None
    relationships[user_id]["partner_username"] = None
    
    # Сбрасываем данные об отношениях партнера
    relationships[partner_id]["partner_id"] = None
    relationships[partner_id]["partner_username"] = None
    
    # Обновляем показатель верности (снижаем на 10 пунктов)
    relationships[user_id]["stats"]["loyalty_score"] = max(0, relationships[user_id]["stats"]["loyalty_score"] - 10)
    
    save_relationships(relationships)
    
    return (True, f"Отношения с @{partner_username} разорваны. 💔")

def get_user_profile(user_id):
    """
    Возвращает данные профиля пользователя.
    
    Args:
        user_id (str): ID пользователя
        
    Returns:
        dict: Данные о пользователе
    """
    relationships = load_relationships()
    user_id = str(user_id)
    
    if user_id not in relationships:
        return None
    
    return relationships[user_id]

def get_relationships_list(chat_id):
    """
    Возвращает список отношений в чате.
    
    Args:
        chat_id (str): ID чата
        
    Returns:
        list: Список пар в отношениях
    """
    relationships = load_relationships()
    chat_id = str(chat_id)
    
    # Ищем все активные отношения в этом чате
    active_relationships = []
    processed_pairs = set()
    
    for user_id, user_data in relationships.items():
        if user_data.get("partner_id"):
            partner_id = user_data["partner_id"]
            
            # Проверяем, что мы еще не обработали эту пару
            pair_key = tuple(sorted([user_id, partner_id]))
            if pair_key in processed_pairs:
                continue
            
            processed_pairs.add(pair_key)
            
            # Проверяем, что оба партнера имеют общую историю отношений в этом чате
            in_this_chat = False
            for rel in user_data["relationships_history"]:
                if rel["partner_id"] == partner_id and rel["status"] == "active":
                    # Попытка получить данные из запросов, так как там сохраняется chat_id
                    found_chat = False
                    
                    if "requests_sent" in user_data:
                        for _, req_data in user_data["requests_sent"].items():
                            if req_data.get("chat_id") == chat_id:
                                found_chat = True
                                break
                    
                    if not found_chat and "requests_received" in user_data:
                        for _, req_data in user_data["requests_received"].items():
                            if req_data.get("chat_id") == chat_id:
                                found_chat = True
                                break
                    
                    # Если не нашли чат, берем всех с активными отношениями
                    if not found_chat or found_chat:
                        in_this_chat = True
                        break
            
            if in_this_chat:
                active_relationships.append({
                    "user1_id": user_id,
                    "user1_username": user_data["username"],
                    "user2_id": partner_id,
                    "user2_username": user_data["partner_username"]
                })
    
    return active_relationships

def toggle_offense(user_id):
    """
    Переключает состояние обиды пользователя.
    
    Args:
        user_id (str): ID пользователя
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    user_id = str(user_id)
    
    # Проверяем, состоит ли пользователь в отношениях
    if user_id not in relationships:
        return (False, "У вас нет профиля отношений.")
    
    # Если пользователь не состоит в отношениях
    if not relationships[user_id].get("partner_id"):
        return (False, "Вы не состоите в отношениях, не на кого обижаться.")
    
    # Переключаем состояние обиды
    relationships[user_id]["is_offended"] = not relationships[user_id]["is_offended"]
    
    status = "обижены" if relationships[user_id]["is_offended"] else "не обижены"
    partner_username = relationships[user_id]["partner_username"]
    
    save_relationships(relationships)
    
    return (True, f"Теперь вы {status} на @{partner_username}.")

def check_partner_loyalty(user_id):
    """
    Проверяет, есть ли у партнера другие отношения.
    
    Args:
        user_id (str): ID пользователя
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    user_id = str(user_id)
    
    # Проверяем, состоит ли пользователь в отношениях
    if user_id not in relationships or not relationships[user_id].get("partner_id"):
        return (False, "Вы не состоите в отношениях.")
    
    # Получаем данные о партнере
    partner_id = relationships[user_id]["partner_id"]
    partner_username = relationships[user_id]["partner_username"]
    
    if partner_id not in relationships:
        return (False, f"Профиль вашего партнера @{partner_username} не найден.")
    
    # Проверяем, есть ли у партнера другие отношения кроме текущих
    if relationships[partner_id]["partner_id"] != user_id:
        other_partner = relationships[partner_id]["partner_username"]
        return (True, f"❌ Ваш партнер @{partner_username} вам неверен! Он/она в отношениях с @{other_partner}.")
    
    # Проверяем историю отношений партнера на предмет измен
    cheating_count = 0
    for rel in relationships[partner_id]["relationships_history"]:
        if rel["partner_id"] != user_id and rel["status"] == "active":
            cheating_count += 1
    
    if cheating_count > 0:
        return (True, f"❌ В прошлом ваш партнер @{partner_username} был замечен в {cheating_count} параллельных отношениях.")
    
    return (True, f"✅ Ваш партнер @{partner_username} верен вам!")

def get_relationship_stats(user_id):
    """
    Возвращает статистику отношений пользователя.
    
    Args:
        user_id (str): ID пользователя
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    user_id = str(user_id)
    
    if user_id not in relationships:
        return (False, "У вас нет профиля отношений.")
    
    user_data = relationships[user_id]
    stats = user_data["stats"]
    
    # Считаем общее количество дней в отношениях
    total_days = 0
    for rel in user_data["relationships_history"]:
        start_time = datetime.fromisoformat(rel["start_time"])
        
        if rel["end_time"]:
            end_time = datetime.fromisoformat(rel["end_time"])
        else:
            end_time = datetime.now()
        
        days_in_rel = (end_time - start_time).days
        total_days += max(1, days_in_rel)
    
    # Обновляем общее количество дней
    stats["total_days_in_relationships"] = total_days
    
    # Формируем текст статистики
    stats_text = "📊 Статистика ваших отношений:\n\n"
    stats_text += f"👫 Всего отношений: {stats['total_relationships']}\n"
    stats_text += f"📅 Общее количество дней в отношениях: {stats['total_days_in_relationships']}\n"
    stats_text += f"💯 Показатель верности: {stats['loyalty_score']}%\n\n"
    
    # Добавляем информацию о текущих отношениях
    if user_data.get("partner_id"):
        partner_username = user_data["partner_username"]
        
        # Находим текущие отношения в истории
        for rel in user_data["relationships_history"]:
            if rel["partner_id"] == user_data["partner_id"] and rel["status"] == "active":
                start_time = datetime.fromisoformat(rel["start_time"])
                days_in_current_rel = (datetime.now() - start_time).days
                stats_text += f"❤️ Текущие отношения с @{partner_username} длятся {days_in_current_rel} дней\n"
                stats_text += f"🎭 Статус: {'В обиде' if user_data['is_offended'] else 'Всё хорошо'}\n"
                break
    
    # Сохраняем обновленные данные
    relationships[user_id]["stats"] = stats
    save_relationships(relationships)
    
    return (True, stats_text)

def get_top_relationships(chat_id=None):
    """
    Возвращает топ отношений по длительности.
    
    Args:
        chat_id (str, optional): ID чата для фильтрации отношений
        
    Returns:
        tuple: (status, message)
    """
    relationships = load_relationships()
    
    # Собираем все активные отношения
    active_pairs = []
    processed_pairs = set()
    
    for user_id, user_data in relationships.items():
        if user_data.get("partner_id"):
            partner_id = user_data["partner_id"]
            
            # Проверяем, что мы еще не обработали эту пару
            pair_key = tuple(sorted([user_id, partner_id]))
            if pair_key in processed_pairs:
                continue
            
            processed_pairs.add(pair_key)
            
            # Находим активные отношения в истории
            for rel in user_data["relationships_history"]:
                if rel["partner_id"] == partner_id and rel["status"] == "active":
                    start_time = datetime.fromisoformat(rel["start_time"])
                    days_in_rel = (datetime.now() - start_time).days
                    
                    # Если указан chat_id, фильтруем по нему
                    include_pair = True
                    if chat_id:
                        # Логика фильтрации по чату (упрощенно, так как у нас нет полной информации о чатах)
                        include_pair = True
                    
                    if include_pair:
                        active_pairs.append({
                            "user1_username": user_data["username"],
                            "user2_username": user_data["partner_username"],
                            "days": days_in_rel
                        })
                    
                    break
    
    # Сортируем по длительности отношений
    active_pairs.sort(key=lambda x: x["days"], reverse=True)
    
    # Формируем текст топа
    top_text = "🏆 Топ отношений по длительности:\n\n"
    
    if not active_pairs:
        return (True, "В данный момент нет активных отношений.")
    
    for i, pair in enumerate(active_pairs[:10], 1):
        top_text += f"{i}. @{pair['user1_username']} + @{pair['user2_username']}: {pair['days']} дней\n"
    
    return (True, top_text)

def get_available_actions():
    """
    Возвращает список доступных действий для отношений.
    
    Returns:
        str: Текст с описанием команд
    """
    actions_text = """
💑 Создание и управление отношениями
📝 Основные команды:
.отн запрос @пользователь — предложить отношения
.отн расторгнуть — разорвать текущие отношения
.отн я — просмотр своего профиля отношений
.отн список — список отношений в беседе
.отн документ — получить свидетельство отношений
.отн контроль — управление всеми вашими отношениями
.отн стата— статистика ваших отношений
.отн топ — рейтинг самых активных отношений
.отн действия — список доступных действий

💔 Проверка верности:
.отн проверка — проверить, есть ли у вашей половинки другие отношения

🙁 Механика обиды:
.отн обида — обидеться на партнера (блокирует действия с вами)
Повторное использование команды снимает обиду
"""
    return actions_text

def is_user_offended(user_id):
    """
    Проверяет, обижен ли пользователь.
    
    Args:
        user_id (str): ID пользователя
        
    Returns:
        bool: True, если пользователь обижен, иначе False
    """
    relationships = load_relationships()
    user_id = str(user_id)
    
    if user_id not in relationships:
        return False
    
    return relationships[user_id].get("is_offended", False)

def is_partner_offended(user_id):
    """
    Проверяет, обижен ли партнер пользователя.
    
    Args:
        user_id (str): ID пользователя
        
    Returns:
        bool: True, если партнер обижен, иначе False
    """
    relationships = load_relationships()
    user_id = str(user_id)
    
    if user_id not in relationships or not relationships[user_id].get("partner_id"):
        return False
    
    partner_id = relationships[user_id]["partner_id"]
    
    if partner_id not in relationships:
        return False
    
    return relationships[partner_id].get("is_offended", False)

def get_relationship_levels_info():
    """
    Возвращает информацию об уровнях отношений и действиях.
    
    Returns:
        str: Текст с описанием уровней и действий
    """
    levels_text = """🌈 Уровни отношений
Ваши отношения развиваются с накоплением искр. Каждый уровень открывает новые действия и возможности!

📊 Таблица уровней и названий:
1: Зарождение интереса
5: Первая близость
10: Безусловная любовь
15: Гармоничная связь
20: Идеальная гармония
25: Нерушимый союз
30: Легендарная любовь

На каждом уровне открываются новые действия, дающие больше искр, но и требующие более длительного восстановления.

🎭 Действия в отношениях
🧠 Базовые действия:
Каждое действие имеет определенную награду в искрах и время восстановления:

💬 сделать комплимент (15 искр, уровень 1)
🍳 сделать завтрак (35 искр, уровень 2)
💐 подарить цветы (60 искр, уровень 3)
🎬 посмотреть фильм (80 искр, уровень 4)
💆 сделать массаж (120 искр, уровень 5)
🕯️ романтический ужин (170 искр, уровень 6)
🎁 сделать подарок (230 искр, уровень 7)
✈️ туристическая поездка (300 искр, уровень 8)
...и многие другие!"""
    
    return levels_text