"""
Модуль для генерации изображений профиля пользователя.
"""

import os
import io
import logging
import tempfile
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import requests
from datetime import datetime
from telegram import User
from handlers.admin_handlers import load_users
from utils.relationships import get_user_profile

logger = logging.getLogger(__name__)

# Константы для генерации изображения
PROFILE_WIDTH = 800
PROFILE_HEIGHT = 500
BACKGROUND_COLOR = (30, 30, 40)
TEXT_COLOR = (230, 230, 230)
ACCENT_COLOR = (100, 150, 255)
SECOND_COLOR = (255, 150, 100)
BORDER_COLOR = (50, 50, 60)
AVATAR_SIZE = 120
AVATAR_BORDER = 5
DEFAULT_FONT_SIZE = 24
TITLE_FONT_SIZE = 36
SUBTITLE_FONT_SIZE = 28

def get_font(size):
    """
    Возвращает объект шрифта указанного размера.
    Пытается использовать системный шрифт, если не получается - использует дефолтный.
    """
    try:
        # Пытаемся использовать стандартный шрифт
        font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
        if os.path.exists(font_path):
            return ImageFont.truetype(font_path, size)
        
        # Альтернативные пути к шрифтам
        font_paths = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/ubuntu/Ubuntu-R.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
        ]
        
        for path in font_paths:
            if os.path.exists(path):
                return ImageFont.truetype(path, size)
                
        # Если не найдены шрифты, используем дефолтный
        return ImageFont.load_default()
    except Exception as e:
        logger.error(f"Ошибка при загрузке шрифта: {e}")
        return ImageFont.load_default()

def download_avatar(user):
    """
    Скачивает аватарку пользователя.
    
    Args:
        user: объект пользователя из telegram
        
    Returns:
        PIL.Image или None, если аватарка не найдена
    """
    try:
        # Простая проверка, чтобы не ломаться, если у бота нет доступа к фотографиям
        # или метод недоступен
        if not hasattr(user, 'get_profile_photos'):
            logger.warning(f"У пользователя {user.id} нет метода get_profile_photos")
            return None
            
        try:
            # Получаем фотографии профиля пользователя
            profile_photos = user.get_profile_photos(limit=1)
            
            if not profile_photos or profile_photos.total_count == 0:
                logger.warning(f"У пользователя {user.id} нет фотографий профиля")
                return None
            
            # Получаем файл фотографии
            photo = profile_photos.photos[0][-1]  # Берем последнюю (самую большую) версию фото
            file = photo.get_file()
            
            # Скачиваем файл
            response = requests.get(file.file_path)
            if response.status_code == 200:
                # Создаем изображение из байтов
                return Image.open(io.BytesIO(response.content))
            else:
                logger.error(f"Не удалось скачать аватарку пользователя {user.id}. Код ответа: {response.status_code}")
                return None
        except AttributeError as ae:
            logger.warning(f"Ошибка доступа к атрибуту при скачивании аватарки: {ae}")
            return None
    except Exception as e:
        logger.error(f"Ошибка при скачивании аватарки пользователя {user.id}: {e}")
        return None

def create_rounded_avatar(avatar_image, size):
    """
    Создает круглую аватарку.
    
    Args:
        avatar_image: изображение аватарки
        size: размер аватарки
        
    Returns:
        PIL.Image: круглая аватарка
    """
    # Создаем маску в форме круга
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, size, size), fill=255)
    
    # Изменяем размер аватарки и применяем маску
    avatar = avatar_image.resize((size, size), Image.LANCZOS)
    result = avatar.copy()
    result.putalpha(mask)
    
    return result

def create_default_avatar(size, username):
    """
    Создает дефолтную аватарку с инициалами.
    
    Args:
        size: размер аватарки
        username: имя пользователя
        
    Returns:
        PIL.Image: дефолтная аватарка
    """
    # Создаем круглое изображение
    avatar = Image.new("RGBA", (size, size), ACCENT_COLOR)
    draw = ImageDraw.Draw(avatar)
    
    # Определяем инициалы
    if username:
        initials = username[0].upper()
    else:
        initials = "?"
    
    # Добавляем текст
    font = get_font(size // 2)
    text_width, text_height = draw.textbbox((0, 0), initials, font=font)[2:4]
    position = ((size - text_width) // 2, (size - text_height) // 2)
    draw.text(position, initials, font=font, fill=TEXT_COLOR)
    
    # Создаем маску в форме круга
    mask = Image.new("L", (size, size), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.ellipse((0, 0, size, size), fill=255)
    
    # Применяем маску
    result = avatar.copy()
    result.putalpha(mask)
    
    return result

def create_profile_image(user, users_data=None, relationship_data=None):
    """
    Создает изображение профиля пользователя.
    
    Args:
        user: объект пользователя из telegram
        users_data: данные о пользователях (если None, загрузит автоматически)
        relationship_data: данные об отношениях (если None, загрузит автоматически)
        
    Returns:
        bytes: байты изображения в формате PNG
    """
    if users_data is None:
        users_data = load_users()
    
    user_id = str(user.id)
    username = user.username or user.first_name
    
    # Создаем основное изображение
    image = Image.new("RGB", (PROFILE_WIDTH, PROFILE_HEIGHT), BACKGROUND_COLOR)
    draw = ImageDraw.Draw(image)
    
    # Рисуем рамку
    draw.rectangle(
        ((5, 5), (PROFILE_WIDTH - 5, PROFILE_HEIGHT - 5)),
        outline=BORDER_COLOR,
        width=2
    )
    
    # Пытаемся скачать аватарку
    avatar_image = download_avatar(user)
    
    # Если не удалось скачать аватарку, создаем дефолтную
    if avatar_image is None:
        avatar = create_default_avatar(AVATAR_SIZE, username)
    else:
        # Создаем круглую аватарку
        avatar = create_rounded_avatar(avatar_image, AVATAR_SIZE)
    
    # Рисуем фон для аватарки
    draw.ellipse(
        [
            (50 - AVATAR_BORDER, 50 - AVATAR_BORDER),
            (50 + AVATAR_SIZE + AVATAR_BORDER, 50 + AVATAR_SIZE + AVATAR_BORDER)
        ],
        fill=BORDER_COLOR
    )
    
    # Вставляем аватарку на изображение
    image.paste(avatar, (50, 50), avatar)
    
    # Рисуем имя пользователя
    title_font = get_font(TITLE_FONT_SIZE)
    draw.text(
        (190, 70),
        f"@{username}",
        font=title_font,
        fill=TEXT_COLOR
    )
    
    # Получаем данные о пользователе из базы
    user_data = users_data.get(user_id, {})
    message_count = user_data.get("message_count", 0)
    balance = user_data.get("balance", 0)
    
    # Получаем данные об отношениях
    relationship_profile = get_user_profile(user_id)
    relationship_status = "Нет отношений"
    relationship_days = 0
    loyalty_score = 100
    
    if relationship_profile and relationship_profile.get("partner_id"):
        partner_username = relationship_profile.get("partner_username", "Неизвестно")
        relationship_status = f"В отношениях с @{partner_username}"
        
        # Ищем активные отношения
        for rel in relationship_profile.get("relationships_history", []):
            if rel.get("status") == "active" and rel.get("partner_id") == relationship_profile.get("partner_id"):
                start_time = datetime.fromisoformat(rel.get("start_time"))
                relationship_days = (datetime.now() - start_time).days
                break
        
        # Получаем показатель верности
        loyalty_score = relationship_profile.get("stats", {}).get("loyalty_score", 100)
    
    # Рисуем статистику
    font = get_font(DEFAULT_FONT_SIZE)
    subtitle_font = get_font(SUBTITLE_FONT_SIZE)
    
    # Блок статистики общения
    draw.rectangle(
        ((30, 190), (PROFILE_WIDTH - 30, 290)),
        fill=BORDER_COLOR,
        outline=ACCENT_COLOR,
        width=2
    )
    
    draw.text(
        (50, 200),
        "Статистика общения:",
        font=subtitle_font,
        fill=ACCENT_COLOR
    )
    
    draw.text(
        (50, 240),
        f"💬 Сообщений: {message_count}",
        font=font,
        fill=TEXT_COLOR
    )
    
    draw.text(
        (400, 240),
        f"💰 Баланс: {balance}",
        font=font,
        fill=TEXT_COLOR
    )
    
    # Блок статистики отношений
    draw.rectangle(
        ((30, 320), (PROFILE_WIDTH - 30, 450)),
        fill=BORDER_COLOR,
        outline=SECOND_COLOR,
        width=2
    )
    
    draw.text(
        (50, 330),
        "Статистика отношений:",
        font=subtitle_font,
        fill=SECOND_COLOR
    )
    
    draw.text(
        (50, 370),
        relationship_status,
        font=font,
        fill=TEXT_COLOR
    )
    
    draw.text(
        (50, 410),
        f"⏱️ Дней в отношениях: {relationship_days}",
        font=font,
        fill=TEXT_COLOR
    )
    
    draw.text(
        (400, 410),
        f"💯 Верность: {loyalty_score}%",
        font=font,
        fill=TEXT_COLOR
    )
    
    # Добавляем информацию об уровне отношений, если пользователь в отношениях
    if relationship_profile and relationship_profile.get("partner_id"):
        relationship_level = relationship_profile.get("stats", {}).get("relationship_level", 1)
        sparks = relationship_profile.get("stats", {}).get("sparks", 0)
        next_level = (relationship_level + 1) * 100
        
        # Блок уровня отношений
        draw.rectangle(
            ((30, 480), (PROFILE_WIDTH - 30, 570)),
            fill=BORDER_COLOR,
            outline=ACCENT_COLOR,
            width=2
        )
        
        draw.text(
            (50, 490),
            f"✨ Уровень отношений: {relationship_level}",
            font=subtitle_font,
            fill=ACCENT_COLOR
        )
        
        # Рисуем прогресс-бар
        progress_width = PROFILE_WIDTH - 120
        progress_height = 25
        progress_x = 60
        progress_y = 530
        
        # Фон прогресс-бара
        draw.rectangle(
            ((progress_x, progress_y), (progress_x + progress_width, progress_y + progress_height)),
            fill=BACKGROUND_COLOR,
            outline=TEXT_COLOR,
            width=1
        )
        
        # Прогресс
        current_progress = min(1.0, sparks / next_level)
        filled_width = int(progress_width * current_progress)
        
        if filled_width > 0:
            draw.rectangle(
                ((progress_x, progress_y), (progress_x + filled_width, progress_y + progress_height)),
                fill=ACCENT_COLOR
            )
        
        # Текст прогресса
        progress_text = f"{sparks}/{next_level} искр"
        text_width, _ = draw.textbbox((0, 0), progress_text, font=font)[2:4]
        draw.text(
            (progress_x + (progress_width - text_width) // 2, progress_y + 3),
            progress_text,
            font=font,
            fill=TEXT_COLOR
        )
    
    # Конвертируем изображение в байты
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format="PNG")
    img_byte_arr.seek(0)
    
    return img_byte_arr.getvalue()