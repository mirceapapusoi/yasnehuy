#!/usr/bin/env python3
"""
Упрощенный скрипт для запуска Telegram бота без веб-интерфейса.
"""

import os
import logging
import sys
from bot import run_bot, BOT_TOKEN

# Настройка логирования
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Функция для запуска бота
def run_telegram_bot():
    """Запускает Telegram бота."""
    # Проверяем наличие токена
    if not BOT_TOKEN:
        logger.error("Токен бота не найден в конфигурации!")
        sys.exit(1)
    
    logger.info("Инициализация Telegram бота Ясен Хуй...")
    logger.info("Запуск Telegram бота...")
    run_bot()

if __name__ == "__main__":
    run_telegram_bot()