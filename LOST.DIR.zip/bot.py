import os
import logging
import re
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    CallbackQueryHandler,
)
from handlers.command_handlers import (
    start_command,
    help_command,
    about_command,
    random_command,
    weather_command,
    admin_panel_command,
    stat_command,
    activity_command,
)
from handlers.message_handlers import handle_message, handle_callback_query
from handlers.conversation_handlers import get_feedback_conversation
from handlers.relationship_handlers import handle_relationship_command, handle_relationship_callback
from config import BOT_TOKEN

logger = logging.getLogger(__name__)

def create_application():
    """Create and configure the Application instance."""
    # Create application with adjusted connection pool settings
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .connection_pool_size(8)  # Увеличиваем размер пула соединений
        .connect_timeout(30.0)    # Увеличиваем таймаут соединения
        .pool_timeout(20.0)       # Увеличиваем таймаут пула
        .read_timeout(30.0)       # Увеличиваем таймаут чтения
        .write_timeout(30.0)      # Увеличиваем таймаут записи
        .build()
    )

    # Add command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("about", about_command))
    application.add_handler(CommandHandler("random", random_command))
    application.add_handler(CommandHandler("weather", weather_command))
    application.add_handler(CommandHandler("admin", admin_panel_command))
    application.add_handler(CommandHandler("stat", stat_command))
    
    # Добавляем текстовый обработчик для команды ".стат"
    application.add_handler(
        MessageHandler(filters.Regex(r'^\.стат\b'), stat_command)
    )
    
    # Добавляем обработчик для команды активности
    application.add_handler(CommandHandler("activity", activity_command))
    
    # Добавляем текстовый обработчик для команды ".актив"
    application.add_handler(
        MessageHandler(filters.Regex(r'^\.актив\b'), activity_command)
    )
    
    # Add conversation handlers
    application.add_handler(get_feedback_conversation)
    
    # Добавляем обработчик для команд отношений (.отн)
    application.add_handler(
        MessageHandler(filters.Regex(r'^\.отн\b'), handle_relationship_command)
    )
    
    # Add callback query handler for relationship buttons
    application.add_handler(CallbackQueryHandler(handle_relationship_callback, pattern=r'^rel_'))
    
    # Add callback query handler for other inline buttons
    application.add_handler(CallbackQueryHandler(handle_callback_query))
    
    # Add message handler (should be last to not interfere with command handlers)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Add handler for photos
    application.add_handler(MessageHandler(filters.PHOTO, handle_message))
    
    # Удаляем обработчик стикеров, т.к. у них сейчас проблемы с поддержкой в filters
    # Вместо этого будем их обрабатывать через метод has_sticker в самом обработчике
    # Добавим обработчик для всех остальных типов сообщений
    application.add_handler(MessageHandler(~filters.TEXT & ~filters.PHOTO & ~filters.COMMAND, handle_message))
    
    # Log all errors
    application.add_error_handler(error_handler)
    
    return application

async def error_handler(update, context):
    """Log errors caused by updates."""
    logger.error(f"Update {update} caused error {context.error}")

def run_bot():
    """Run the bot until the user presses Ctrl-C."""
    application = create_application()
    
    # Run the bot until the user presses Ctrl-C
    logger.info("Bot is starting...")
    # Используем стандартный метод для запуска бота без специфичных параметров
    application.run_polling()
