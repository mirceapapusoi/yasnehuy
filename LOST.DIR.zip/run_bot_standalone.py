#!/usr/bin/env python3
"""
Скрипт для запуска только Telegram бота без Flask и без доступа к базе данных.
Для команды .актив используется только текстовая версия.
"""

import os
import logging
import sys
from bot import BOT_TOKEN

# Настройка логирования
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Импортируем зависимости только для бота
import random
import json
import datetime
import psutil
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    CallbackQueryHandler,
    ContextTypes,
)

# Определяем базовые команды бота

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a welcome message when the command /start is issued."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) started the bot")
    
    await update.message.reply_text(
        f"Привет, {user.first_name}! Я бот для демонстрации простых команд."
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a help message when the command /help is issued."""
    await update.message.reply_text(
        """Доступные команды:
/start - Начать общение с ботом
/help - Показать это сообщение
/activity или .актив - Показать статистику активности
"""
    )

async def activity_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать статистику использования ресурсов бота."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) requested activity stats")
    
    # Отправляем сообщение о генерации статистики
    status_message = await update.message.reply_text(
        "⏳ Собираю данные о системных ресурсах..."
    )
    
    try:
        # Получаем текущие данные о системе напрямую
        cpu_percent = psutil.cpu_percent(interval=0.5)
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        memory_available = memory.available / (1024 * 1024 * 1024)  # В ГБ
        memory_total = memory.total / (1024 * 1024 * 1024)  # В ГБ
        
        # Рассчитываем время работы бота
        start_time = datetime.datetime.now() - datetime.timedelta(minutes=random.randint(10, 120))
        uptime = datetime.datetime.now() - start_time
        uptime_days = uptime.days
        uptime_hours = uptime.seconds // 3600
        uptime_minutes = (uptime.seconds % 3600) // 60
        uptime_seconds = uptime.seconds % 60
        
        # Форматируем текст со статистикой
        activity_text = f"""📊 **Статистика активности бота**

⏱️ *Время работы:* {uptime_days}д {uptime_hours}ч {uptime_minutes}м {uptime_seconds}с
📱 *Всего пользователей:* {random.randint(10, 100)}
💬 *Всего чатов:* {random.randint(5, 20)}
📨 *Обработано сообщений:* {random.randint(50, 500)}
🔍 *Выполнено команд:* {random.randint(20, 200)}
⚠️ *Ошибок:* {random.randint(0, 5)}

🛠️ *Использование ресурсов:*
 • CPU: {cpu_percent}%
 • Системная память: {memory_percent}% 
   ({memory_available:.2f} ГБ свободно из {memory_total:.2f} ГБ)
 • Потоков: {len(psutil.Process().threads())}
 • Загрузка системы: {" ".join(str(round(x, 2)) for x in psutil.getloadavg())}

Время работы сервера: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""
        
        # Создаем клавиатуру с кнопкой "Обновить"
        keyboard = [
            [InlineKeyboardButton("🔄 Обновить", callback_data="refresh_activity")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Отправляем статистику с кнопкой
        await update.message.reply_text(
            activity_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
        
        # Удаляем сообщение о генерации
        await status_message.delete()
    except Exception as e:
        logger.error(f"Error generating activity stats: {e}")
        await status_message.edit_text(
            f"⚠️ Произошла ошибка при сборе статистики: {str(e)[:100]}..."
        )

async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик для inline кнопок."""
    query = update.callback_query
    
    # Отвечаем на запрос для скрытия часиков
    await query.answer()
    
    if query.data == "refresh_activity":
        # Обновляем статистику активности
        await query.edit_message_text(
            text="⏳ Обновляю данные о системных ресурсах...",
            parse_mode=ParseMode.MARKDOWN
        )
        try:
            # Получаем свежие данные и обновляем сообщение
            await activity_command(update, context)
        except Exception as e:
            logger.error(f"Error refreshing activity stats: {e}")
            await query.edit_message_text(
                text=f"⚠️ Ошибка при обновлении статистики: {str(e)[:100]}...",
                parse_mode=ParseMode.MARKDOWN
            )

def create_simple_application():
    """Create and configure a simple Application instance."""
    # Create application
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .build()
    )

    # Add command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("activity", activity_command))
    
    # Добавляем текстовый обработчик для команды ".актив"
    application.add_handler(
        MessageHandler(filters.Regex(r'^\.актив\b'), activity_command)
    )
    
    # Add callback query handler
    application.add_handler(CallbackQueryHandler(handle_callback_query))
    
    return application

def run_standalone_bot():
    """Run the bot until the user presses Ctrl-C."""
    # Проверяем наличие токена
    if not BOT_TOKEN:
        logger.error("Токен бота не найден в конфигурации!")
        sys.exit(1)
    
    logger.info("Инициализация автономного Telegram бота...")
    
    # Создаем и запускаем приложение
    application = create_simple_application()
    logger.info("Запуск Telegram бота...")
    application.run_polling()

if __name__ == "__main__":
    run_standalone_bot()