"""
Обработчики команд для управления отношениями между пользователями.
"""

import logging
import re
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils.relationships import (
    create_relationship_request, break_relationship, get_user_profile,
    get_relationships_list, toggle_offense, check_partner_loyalty,
    get_relationship_stats, get_top_relationships, get_available_actions,
    is_user_offended, is_partner_offended, accept_relationship_request,
    reject_relationship_request, cancel_relationship_request
)

logger = logging.getLogger(__name__)

# Регулярное выражение для извлечения имени пользователя
USERNAME_PATTERN = r"@([a-zA-Z0-9_]{5,32})"

async def handle_relationship_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Обрабатывает команды для управления отношениями.
    
    Формат команд:
    .отн запрос @username - отправить запрос на отношения
    .отн расторгнуть - разорвать текущие отношения
    .отн я - посмотреть свой профиль отношений
    .отн список - список отношений в беседе
    .отн документ - получить свидетельство отношений
    .отн контроль - управление отношениями
    .отн стата - статистика отношений
    .отн топ - рейтинг отношений
    .отн действия - список доступных действий
    .отн проверка - проверить верность партнера
    .отн обида - обидеться на партнера
    """
    message = update.message
    user = update.effective_user
    user_id = str(user.id)
    chat_id = str(message.chat_id)
    
    # Проверяем формат команды
    command_parts = message.text.split(" ", 2)
    
    if len(command_parts) < 2:
        await message.reply_text(
            "Неверный формат команды. Используйте '.отн действия' для просмотра доступных команд."
        )
        return
    
    subcommand = command_parts[1].lower()
    
    # Обрабатываем различные типы команд
    if subcommand == "запрос":
        await handle_relationship_request(update, context)
    elif subcommand == "расторгнуть":
        await handle_relationship_breakup(update, context)
    elif subcommand == "я":
        await handle_profile_view(update, context)
    elif subcommand == "список":
        await handle_relationships_list(update, context)
    elif subcommand == "документ":
        await handle_relationship_certificate(update, context)
    elif subcommand == "контроль":
        await handle_relationship_control(update, context)
    elif subcommand == "стата":
        await handle_relationship_stats(update, context)
    elif subcommand == "топ":
        await handle_relationships_top(update, context)
    elif subcommand == "действия":
        await handle_available_actions(update, context)
    elif subcommand == "проверка":
        await handle_loyalty_check(update, context)
    elif subcommand == "обида":
        await handle_offense_toggle(update, context)
    else:
        await message.reply_text(
            "Неизвестная команда. Используйте '.отн действия' для просмотра доступных команд."
        )

async def handle_relationship_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает запрос на отношения."""
    message = update.message
    user = update.effective_user
    from_user_id = user.id
    from_username = user.username or user.first_name
    chat_id = message.chat_id
    
    # Ищем имя пользователя в сообщении
    command_parts = message.text.split(" ", 2)
    if len(command_parts) < 3:
        await message.reply_text(
            "Укажите имя пользователя, которому хотите отправить запрос на отношения.\n"
            "Например: .отн запрос @username"
        )
        return
    
    # Извлекаем имя пользователя
    username_match = re.search(USERNAME_PATTERN, command_parts[2])
    if not username_match:
        await message.reply_text(
            "Не удалось распознать имя пользователя. Используйте формат @username."
        )
        return
    
    to_username = username_match.group(1)
    
    # Проверяем, не отправляет ли пользователь запрос самому себе
    if to_username.lower() == from_username.lower():
        await message.reply_text(
            "Вы не можете отправить запрос на отношения самому себе! 😅"
        )
        return
    
    # Проверяем, есть ли такой пользователь в чате
    to_user = None
    for member in await context.bot.get_chat_administrators(chat_id):
        if member.user.username and member.user.username.lower() == to_username.lower():
            to_user = member.user
            break
    
    # Если пользователь не найден среди администраторов, проверяем всех участников
    # (это может быть ресурсоемкой операцией для больших групп)
    if to_user is None:
        try:
            chat_member = await message.chat.get_member(username="@" + to_username)
            to_user = chat_member.user
        except Exception as e:
            logger.warning(f"Error getting chat member: {e}")
            # Если пользователь не найден, продолжаем с указанным именем пользователя
            # и назначаем временный ID
            to_user_id = f"user_{to_username}"
            
            # Отправляем запрос на отношения
            status, response = create_relationship_request(
                from_user_id, to_user_id, from_username, to_username, chat_id
            )
            
            await message.reply_text(response)
            return
    
    # Отправляем запрос на отношения
    to_user_id = to_user.id
    status, response = create_relationship_request(
        from_user_id, to_user_id, from_username, to_username, chat_id
    )
    
    await message.reply_text(response)
    
    # Если запрос отправлен успешно, отправляем уведомление получателю
    if status:
        try:
            # Создаем клавиатуру с кнопками для принятия/отклонения запроса
            keyboard = [
                [
                    InlineKeyboardButton("✅ Принять", callback_data=f"rel_accept_{from_user_id}"),
                    InlineKeyboardButton("❌ Отклонить", callback_data=f"rel_reject_{from_user_id}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await context.bot.send_message(
                chat_id=to_user_id,
                text=f"💌 У вас новый запрос на отношения от @{from_username}!\n"
                     f"Вы можете принять или отклонить его с помощью кнопок ниже.",
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Не удалось отправить уведомление пользователю {to_user_id}: {e}")

async def handle_relationship_breakup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает разрыв отношений."""
    message = update.message
    user = update.effective_user
    user_id = user.id
    
    # Проверяем, обижен ли партнер
    if is_partner_offended(user_id):
        await message.reply_text(
            "Ваш партнер обижен на вас и не желает общаться. Дождитесь, пока обида пройдет."
        )
        return
    
    # Разрываем отношения
    status, response = break_relationship(user_id)
    
    await message.reply_text(response)

async def handle_profile_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает профиль отношений пользователя."""
    message = update.message
    user = update.effective_user
    user_id = user.id
    
    profile = get_user_profile(user_id)
    
    if not profile:
        await message.reply_text(
            "У вас еще нет профиля отношений. Используйте '.отн запрос @username' для создания отношений."
        )
        return
    
    # Формируем текст профиля
    profile_text = f"👤 Профиль отношений @{user.username or user.first_name}:\n\n"
    
    if profile.get("partner_id"):
        partner_username = profile["partner_username"]
        profile_text += f"❤️ В отношениях с @{partner_username}\n"
        profile_text += f"🎭 Статус: {'В обиде' if profile['is_offended'] else 'Всё хорошо'}\n\n"
    else:
        profile_text += "💔 Сейчас не в отношениях\n\n"
    
    # Добавляем статистику
    stats = profile["stats"]
    profile_text += f"📊 Статистика:\n"
    profile_text += f"👫 Всего отношений: {stats['total_relationships']}\n"
    profile_text += f"📅 Дней в отношениях: {stats['total_days_in_relationships']}\n"
    profile_text += f"💯 Верность: {stats['loyalty_score']}%\n\n"
    
    # Добавляем информацию о запросах
    requests_sent = profile.get("requests_sent", {})
    requests_received = profile.get("requests_received", {})
    
    if requests_sent:
        profile_text += "📤 Отправленные запросы:\n"
        for user_id, req_data in requests_sent.items():
            profile_text += f"• @{req_data['username']}\n"
        profile_text += "\n"
    
    if requests_received:
        profile_text += "📥 Полученные запросы:\n"
        for user_id, req_data in requests_received.items():
            profile_text += f"• @{req_data['username']}\n"
            
            # Создаем клавиатуру с кнопками для принятия/отклонения запроса
            keyboard = [
                [
                    InlineKeyboardButton("✅ Принять", callback_data=f"rel_accept_{user_id}"),
                    InlineKeyboardButton("❌ Отклонить", callback_data=f"rel_reject_{user_id}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await context.bot.send_message(
                chat_id=update.effective_user.id,
                text=f"💌 У вас есть запрос на отношения от @{req_data['username']}:",
                reply_markup=reply_markup
            )
    
    await message.reply_text(profile_text)

async def handle_relationships_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает список отношений в чате."""
    message = update.message
    chat_id = message.chat_id
    
    relationships = get_relationships_list(chat_id)
    
    if not relationships:
        await message.reply_text(
            "В этом чате пока нет пар в отношениях."
        )
        return
    
    # Формируем текст списка отношений
    list_text = "💑 Список пар в этом чате:\n\n"
    
    for i, rel in enumerate(relationships, 1):
        list_text += f"{i}. @{rel['user1_username']} ❤️ @{rel['user2_username']}\n"
    
    await message.reply_text(list_text)

async def handle_relationship_certificate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправляет свидетельство об отношениях."""
    message = update.message
    user = update.effective_user
    user_id = user.id
    
    profile = get_user_profile(user_id)
    
    if not profile or not profile.get("partner_id"):
        await message.reply_text(
            "У вас нет активных отношений для получения свидетельства."
        )
        return
    
    # Проверяем, обижен ли партнер
    if is_partner_offended(user_id):
        await message.reply_text(
            "Ваш партнер обижен на вас и не желает общаться. Дождитесь, пока обида пройдет."
        )
        return
    
    partner_username = profile["partner_username"]
    
    # Создаем текст свидетельства
    certificate_text = """
    🏆 СВИДЕТЕЛЬСТВО ОБ ОТНОШЕНИЯХ 🏆
    
    Настоящим подтверждается, что
    
    @{user_username} и @{partner_username}
    
    официально состоят в отношениях
    
    ❤️❤️❤️
    
    Дата выдачи: {date}
    """
    
    # Форматируем текст
    import datetime
    today = datetime.datetime.now().strftime("%d.%m.%Y")
    
    certificate_text = certificate_text.format(
        user_username=user.username or user.first_name,
        partner_username=partner_username,
        date=today
    )
    
    await message.reply_text(certificate_text)

async def handle_relationship_control(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает панель управления отношениями."""
    message = update.message
    user = update.effective_user
    user_id = user.id
    
    profile = get_user_profile(user_id)
    
    if not profile:
        await message.reply_text(
            "У вас еще нет профиля отношений. Используйте '.отн запрос @username' для создания отношений."
        )
        return
    
    # Создаем кнопки управления
    keyboard = []
    
    if profile.get("partner_id"):
        keyboard.append([InlineKeyboardButton("💔 Расторгнуть отношения", callback_data="rel_break")])
        keyboard.append([InlineKeyboardButton("🙁 Обида", callback_data="rel_offense")])
        keyboard.append([InlineKeyboardButton("🕵️ Проверка верности", callback_data="rel_check")])
    
    # Добавляем общие кнопки управления
    keyboard.append([InlineKeyboardButton("📊 Статистика", callback_data="rel_stats")])
    keyboard.append([InlineKeyboardButton("📜 Свидетельство", callback_data="rel_certificate")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await message.reply_text(
        "Панель управления отношениями. Выберите действие:",
        reply_markup=reply_markup
    )

async def handle_relationship_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает статистику отношений пользователя."""
    message = update.message
    user = update.effective_user
    user_id = user.id
    
    status, response = get_relationship_stats(user_id)
    
    await message.reply_text(response)

async def handle_relationships_top(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает топ отношений."""
    message = update.message
    chat_id = message.chat_id
    
    status, response = get_top_relationships(chat_id)
    
    await message.reply_text(response)

async def handle_available_actions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает список доступных действий для отношений."""
    message = update.message
    
    actions_text = get_available_actions()
    
    await message.reply_text(actions_text)

async def handle_loyalty_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверяет верность партнера."""
    message = update.message
    user = update.effective_user
    user_id = user.id
    
    # Проверяем, обижен ли партнер
    if is_partner_offended(user_id):
        await message.reply_text(
            "Ваш партнер обижен на вас и не желает общаться. Дождитесь, пока обида пройдет."
        )
        return
    
    status, response = check_partner_loyalty(user_id)
    
    await message.reply_text(response)

async def handle_offense_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Включает/выключает режим обиды."""
    message = update.message
    user = update.effective_user
    user_id = user.id
    
    status, response = toggle_offense(user_id)
    
    await message.reply_text(response)

async def handle_relationship_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатия на кнопки в панели управления отношениями."""
    query = update.callback_query
    user = query.from_user
    user_id = user.id
    username = user.username or user.first_name
    
    # Уведомляем Telegram, что мы обработали запрос
    await query.answer()
    
    # Обрабатываем различные действия
    if query.data == "rel_break":
        status, response = break_relationship(user_id)
        await query.message.edit_text(response)
    
    elif query.data == "rel_offense":
        status, response = toggle_offense(user_id)
        await query.message.edit_text(response)
    
    elif query.data == "rel_check":
        # Проверяем, обижен ли партнер
        if is_partner_offended(user_id):
            await query.message.edit_text(
                "Ваш партнер обижен на вас и не желает общаться. Дождитесь, пока обида пройдет."
            )
            return
        
        status, response = check_partner_loyalty(user_id)
        await query.message.edit_text(response)
    
    elif query.data == "rel_stats":
        status, response = get_relationship_stats(user_id)
        await query.message.edit_text(response)
    
    elif query.data == "rel_certificate":
        profile = get_user_profile(user_id)
        
        if not profile or not profile.get("partner_id"):
            await query.message.edit_text(
                "У вас нет активных отношений для получения свидетельства."
            )
            return
        
        # Проверяем, обижен ли партнер
        if is_partner_offended(user_id):
            await query.message.edit_text(
                "Ваш партнер обижен на вас и не желает общаться. Дождитесь, пока обида пройдет."
            )
            return
        
        partner_username = profile["partner_username"]
        
        # Создаем текст свидетельства
        certificate_text = """
        🏆 СВИДЕТЕЛЬСТВО ОБ ОТНОШЕНИЯХ 🏆
        
        Настоящим подтверждается, что
        
        @{user_username} и @{partner_username}
        
        официально состоят в отношениях
        
        ❤️❤️❤️
        
        Дата выдачи: {date}
        """
        
        # Форматируем текст
        import datetime
        today = datetime.datetime.now().strftime("%d.%m.%Y")
        
        certificate_text = certificate_text.format(
            user_username=username,
            partner_username=partner_username,
            date=today
        )
        
        await query.message.edit_text(certificate_text)
    
    # Обработка запросов на принятие/отклонение отношений
    elif query.data.startswith("rel_accept_"):
        from_user_id = query.data.split("_")[2]
        
        # Получаем данные отправителя
        profile = get_user_profile(from_user_id)
        
        if not profile:
            await query.message.edit_text(
                "Профиль отправителя запроса не найден."
            )
            return
        
        from_username = profile.get("username", "Неизвестный пользователь")
        
        # Принимаем запрос
        status, response = accept_relationship_request(
            from_user_id, user_id, from_username, username, query.message.chat_id
        )
        
        await query.message.edit_text(response)
        
        # Отправляем уведомление отправителю
        try:
            await context.bot.send_message(
                chat_id=from_user_id,
                text=f"❤️ @{username} принял(а) ваш запрос на отношения! Поздравляем!"
            )
        except Exception as e:
            logger.error(f"Не удалось отправить уведомление пользователю {from_user_id}: {e}")
    
    elif query.data.startswith("rel_reject_"):
        from_user_id = query.data.split("_")[2]
        
        # Получаем данные отправителя
        profile = get_user_profile(from_user_id)
        
        if not profile:
            await query.message.edit_text(
                "Профиль отправителя запроса не найден."
            )
            return
        
        from_username = profile.get("username", "Неизвестный пользователь")
        
        # Отклоняем запрос
        status, response = reject_relationship_request(from_user_id, user_id)
        
        await query.message.edit_text(f"Вы отклонили запрос на отношения от @{from_username}.")
        
        # Отправляем уведомление отправителю
        try:
            await context.bot.send_message(
                chat_id=from_user_id,
                text=f"💔 @{username} отклонил(а) ваш запрос на отношения."
            )
        except Exception as e:
            logger.error(f"Не удалось отправить уведомление пользователю {from_user_id}: {e}")