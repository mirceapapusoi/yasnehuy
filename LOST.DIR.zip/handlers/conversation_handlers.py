import logging
import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes,
    ConversationHandler,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)
from config import RESPONSES

logger = logging.getLogger(__name__)

# States for the feedback conversation
FEEDBACK = 1
RATING = 2

async def feedback_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start the feedback conversation."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) started feedback")
    
    # Создаем клавиатуру с рейтингом от 1 до 5
    keyboard = [
        [
            InlineKeyboardButton("1 ⭐", callback_data="rating_1"),
            InlineKeyboardButton("2 ⭐", callback_data="rating_2"),
            InlineKeyboardButton("3 ⭐", callback_data="rating_3"),
            InlineKeyboardButton("4 ⭐", callback_data="rating_4"),
            InlineKeyboardButton("5 ⭐", callback_data="rating_5"),
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Пожалуйста, сначала оцените бота от 1 до 5 звезд:",
        reply_markup=reply_markup
    )
    return RATING

async def receive_rating(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Получить оценку от пользователя и запросить текстовый отзыв."""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    rating = query.data.split("_")[1]
    
    # Сохраняем рейтинг в данных пользователя
    context.user_data["feedback_rating"] = rating
    
    logger.info(f"User {user.id} ({user.username}) gave rating: {rating}")
    
    await query.message.reply_text(
        f"Спасибо за оценку {rating}! {RESPONSES['feedback_start']}"
    )
    return FEEDBACK

async def receive_feedback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Receive and store user feedback."""
    user_feedback = update.message.text
    user = update.effective_user
    
    # Получаем рейтинг из данных пользователя
    rating = context.user_data.get("feedback_rating", "Не указано")
    
    # Текущее время
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Log the feedback with rating
    logger.info(f"Received feedback from {user.id} ({user.username}): Rating: {rating}, Text: {user_feedback}")
    
    # Здесь можно сохранить отзыв в базу данных
    
    await update.message.reply_text(RESPONSES["feedback_received"])
    return ConversationHandler.END

async def cancel_feedback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel the feedback conversation."""
    await update.message.reply_text(RESPONSES["feedback_cancel"])
    return ConversationHandler.END

# Create the conversation handler for feedback
get_feedback_conversation = ConversationHandler(
    entry_points=[CommandHandler("feedback", feedback_start)],
    states={
        RATING: [
            CallbackQueryHandler(receive_rating, pattern=r"^rating_[1-5]$"),
        ],
        FEEDBACK: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, receive_feedback),
        ],
    },
    fallbacks=[CommandHandler("cancel", cancel_feedback)],
)
