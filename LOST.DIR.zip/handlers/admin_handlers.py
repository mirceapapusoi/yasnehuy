import logging
import json
import os
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import ADMIN_IDS, DATA_DIR

logger = logging.getLogger(__name__)

# Создание директории для данных, если она не существует
os.makedirs(DATA_DIR, exist_ok=True)

# Путь к файлу с данными пользователей
USERS_FILE = os.path.join(DATA_DIR, "users.json")
BANNED_USERS_FILE = os.path.join(DATA_DIR, "banned_users.json")

def load_users():
    """Загрузка данных о пользователях."""
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.error("Ошибка декодирования JSON из файла пользователей")
            return {}
    return {}

def save_users(users_data):
    """Сохранение данных о пользователях."""
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(users_data, f, ensure_ascii=False, indent=2)

def load_banned_users():
    """Загрузка данных о заблокированных пользователях."""
    if os.path.exists(BANNED_USERS_FILE):
        try:
            with open(BANNED_USERS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.error("Ошибка декодирования JSON из файла заблокированных пользователей")
            return {}
    return {}

def save_banned_users(banned_users):
    """Сохранение данных о заблокированных пользователях."""
    with open(BANNED_USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(banned_users, f, ensure_ascii=False, indent=2)

def is_admin(user_id):
    """Проверка, является ли пользователь администратором."""
    return str(user_id) in ADMIN_IDS

def update_user_data(user):
    """Обновление данных о пользователе."""
    users = load_users()
    
    user_id = str(user.id)
    if user_id not in users:
        # Новый пользователь
        users[user_id] = {
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "messages_count": 0,
            "first_seen": datetime.now().isoformat(),
            "last_activity": datetime.now().isoformat()
        }
    else:
        # Обновляем существующего пользователя
        users[user_id]["username"] = user.username
        users[user_id]["first_name"] = user.first_name
        users[user_id]["last_name"] = user.last_name
        users[user_id]["last_activity"] = datetime.now().isoformat()
        users[user_id]["messages_count"] += 1
    
    save_users(users)
    return users[user_id]

def is_user_banned(user_id):
    """Проверка, заблокирован ли пользователь."""
    banned_users = load_banned_users()
    return str(user_id) in banned_users

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать панель администратора."""
    user = update.effective_user
    
    # Проверяем, является ли пользователь администратором
    if not is_admin(user.id):
        await update.message.reply_text("У вас нет прав для использования этой команды.")
        logger.warning(f"Пользователь {user.id} ({user.username}) попытался использовать команду администратора")
        return
    
    # Создаем панель администратора с кнопками
    keyboard = [
        [
            InlineKeyboardButton("Статистика", callback_data="admin_stats"),
            InlineKeyboardButton("Список пользователей", callback_data="admin_users")
        ],
        [
            InlineKeyboardButton("Рассылка", callback_data="admin_broadcast"),
            InlineKeyboardButton("Управление банами", callback_data="admin_bans")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Панель администратора. Выберите действие:",
        reply_markup=reply_markup
    )

async def handle_admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка callback запросов от администратора."""
    query = update.callback_query
    user = query.from_user
    
    # Проверяем, является ли пользователь администратором
    if not is_admin(user.id):
        await query.answer("У вас нет прав для выполнения этого действия.", show_alert=True)
        logger.warning(f"Пользователь {user.id} ({user.username}) попытался выполнить admin callback")
        return
    
    await query.answer()
    
    # Обработка различных действий администратора
    if query.data == "admin_stats":
        await show_stats(query, context)
    elif query.data == "admin_users":
        await show_users(query, context)
    elif query.data == "admin_broadcast":
        await start_broadcast(query, context)
    elif query.data == "admin_bans":
        await manage_bans(query, context)
    elif query.data == "admin_back":
        # Возврат в главное меню администратора
        keyboard = [
            [
                InlineKeyboardButton("Статистика", callback_data="admin_stats"),
                InlineKeyboardButton("Пользователи", callback_data="admin_users")
            ],
            [
                InlineKeyboardButton("Рассылка", callback_data="admin_broadcast"),
                InlineKeyboardButton("Управление банами", callback_data="admin_bans")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.edit_text(
            "Панель администратора. Выберите действие:",
            reply_markup=reply_markup
        )
    elif query.data == "admin_cancel_broadcast":
        # Отмена рассылки
        if "admin_state" in context.user_data:
            del context.user_data["admin_state"]
        if "broadcast_text" in context.user_data:
            del context.user_data["broadcast_text"]
        
        # Возврат в главное меню
        keyboard = [
            [
                InlineKeyboardButton("Статистика", callback_data="admin_stats"),
                InlineKeyboardButton("Пользователи", callback_data="admin_users")
            ],
            [
                InlineKeyboardButton("Рассылка", callback_data="admin_broadcast"),
                InlineKeyboardButton("Управление банами", callback_data="admin_bans")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.edit_text(
            "Рассылка отменена. Панель администратора:",
            reply_markup=reply_markup
        )
    elif query.data == "admin_confirm_broadcast":
        # Подтверждение и начало рассылки
        await confirm_broadcast(query, context)
    elif query.data.startswith("ban_user_"):
        user_id = query.data.split("_")[2]
        await ban_user(query, context, user_id)
    elif query.data.startswith("unban_user_"):
        user_id = query.data.split("_")[2]
        await unban_user(query, context, user_id)

async def show_stats(query, context):
    """Показать статистику бота."""
    users = load_users()
    banned_users = load_banned_users()
    
    total_users = len(users)
    total_messages = sum(user.get("messages_count", 0) for user in users.values())
    total_banned = len(banned_users)
    
    # Найти наиболее активных пользователей
    active_users = sorted(
        users.items(), 
        key=lambda x: x[1].get("messages_count", 0), 
        reverse=True
    )[:5]
    
    # Формируем текст статистики
    stats_text = (
        "📊 Статистика бота\n\n"
        f"👥 Всего пользователей: {total_users}\n"
        f"💬 Всего сообщений: {total_messages}\n"
        f"🚫 Заблокировано пользователей: {total_banned}\n\n"
        "Наиболее активные пользователи:\n"
    )
    
    for i, (user_id, user_data) in enumerate(active_users, 1):
        username = user_data.get("username", "Нет имени")
        first_name = user_data.get("first_name", "")
        messages = user_data.get("messages_count", 0)
        # Для безопасности удаляем символы Markdown из имени пользователя
        if username:
            username = username.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`")
        if first_name:
            first_name = first_name.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`")
        stats_text += f"{i}. {first_name} (@{username}): {messages} сообщений\n"
    
    # Добавляем кнопку возврата
    keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="admin_back")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await query.message.edit_text(
            stats_text,
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Ошибка при показе статистики: {e}")
        await query.message.reply_text(
            "Ошибка при отображении статистики. Попробуйте еще раз.",
            reply_markup=reply_markup
        )

async def show_users(query, context):
    """Показать список пользователей."""
    users = load_users()
    
    # Сортируем пользователей по дате последней активности
    sorted_users = sorted(
        users.items(),
        key=lambda x: x[1].get("last_activity", ""),
        reverse=True
    )[:10]  # Показываем только первые 10 пользователей
    
    # Формируем текст со списком пользователей
    users_text = "👥 Список последних активных пользователей:\n\n"
    
    for i, (user_id, user_data) in enumerate(sorted_users, 1):
        username = user_data.get("username", "Нет имени")
        first_name = user_data.get("first_name", "")
        last_activity = user_data.get("last_activity", "")
        
        # Для безопасности удаляем символы Markdown из имени пользователя
        if username:
            username = username.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`")
        if first_name:
            first_name = first_name.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`")
        
        # Преобразуем ISO формат даты в более читаемый
        try:
            activity_date = datetime.fromisoformat(last_activity)
            formatted_date = activity_date.strftime("%d.%m.%Y %H:%M")
        except (ValueError, TypeError):
            formatted_date = "неизвестно"
        
        users_text += f"{i}. {first_name} (@{username}) - Был активен: {formatted_date}\n"
    
    # Создаем кнопки для управления пользователями
    keyboard = []
    for i, (user_id, _) in enumerate(sorted_users[:5], 1):  # Добавляем кнопки только для первых 5 пользователей
        banned = is_user_banned(user_id)
        action = "Разбанить" if banned else "Забанить"
        callback_data = f"unban_user_{user_id}" if banned else f"ban_user_{user_id}"
        keyboard.append([InlineKeyboardButton(f"{action} #{i}", callback_data=callback_data)])
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="admin_back")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.edit_text(
        users_text,
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def start_broadcast(query, context):
    """Начать процесс рассылки сообщений."""
    # Сохраняем в пользовательских данных, что мы в режиме создания рассылки
    context.user_data["admin_state"] = "creating_broadcast"
    
    # Создаем кнопку отмены
    keyboard = [[InlineKeyboardButton("❌ Отменить", callback_data="admin_cancel_broadcast")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.edit_text(
        "📣 Создание рассылки\n\n"
        "Отправьте сообщение, которое хотите разослать всем пользователям.\n"
        "Вы можете использовать Markdown для форматирования текста.\n\n"
        "Например: *жирный текст*, _курсив_, `код`\n\n"
        "Для отмены нажмите кнопку ниже.",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def process_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка сообщения для рассылки."""
    user = update.effective_user
    
    # Проверяем, является ли пользователь администратором и находится ли в режиме создания рассылки
    if not is_admin(user.id) or context.user_data.get("admin_state") != "creating_broadcast":
        return
    
    broadcast_text = update.message.text
    
    # Сохраняем текст рассылки
    context.user_data["broadcast_text"] = broadcast_text
    
    # Создаем кнопки подтверждения/отмены рассылки
    keyboard = [
        [
            InlineKeyboardButton("✅ Подтвердить", callback_data="admin_confirm_broadcast"),
            InlineKeyboardButton("❌ Отменить", callback_data="admin_cancel_broadcast")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        f"📣 Предпросмотр рассылки:\n\n"
        f"{broadcast_text}\n\n"
        f"Вы уверены, что хотите отправить это сообщение всем пользователям?",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def confirm_broadcast(query, context):
    """Подтверждение и выполнение рассылки."""
    broadcast_text = context.user_data.get("broadcast_text", "")
    
    if not broadcast_text:
        await query.answer("Ошибка: текст рассылки не найден", show_alert=True)
        return
    
    # Получаем список пользователей для рассылки
    users = load_users()
    banned_users = load_banned_users()
    
    # Счетчики для статистики
    total_users = len(users)
    sent_count = 0
    error_count = 0
    skipped_count = 0
    
    # Отправляем промежуточное сообщение о начале рассылки
    await query.message.edit_text(
        "📣 Рассылка началась\n\n"
        f"Всего получателей: {total_users}",
        parse_mode="Markdown"
    )
    
    # Выполняем рассылку
    for user_id, user_data in users.items():
        # Пропускаем заблокированных пользователей
        if user_id in banned_users:
            skipped_count += 1
            continue
        
        try:
            # Отправляем сообщение пользователю
            await context.bot.send_message(
                chat_id=user_id,
                text=f"📣 Сообщение от администрации:\n\n{broadcast_text}",
                parse_mode="Markdown"
            )
            sent_count += 1
            
            # Чтобы не злоупотреблять API, делаем паузу между отправками
            # await asyncio.sleep(0.1)
            
        except Exception as e:
            error_count += 1
            logger.error(f"Ошибка при отправке рассылки пользователю {user_id}: {e}")
    
    # Отправляем итоговый отчет
    await query.message.edit_text(
        "📣 Рассылка завершена\n\n"
        f"✅ Успешно отправлено: {sent_count}\n"
        f"❌ Ошибок: {error_count}\n"
        f"⏭️ Пропущено (заблокированы): {skipped_count}\n\n"
        f"Всего получателей было: {total_users}",
        parse_mode="Markdown"
    )
    
    # Очищаем состояние
    if "admin_state" in context.user_data:
        del context.user_data["admin_state"]
    if "broadcast_text" in context.user_data:
        del context.user_data["broadcast_text"]

async def manage_bans(query, context):
    """Управление заблокированными пользователями."""
    banned_users = load_banned_users()
    users = load_users()
    
    # Формируем список заблокированных пользователей
    banned_text = "🚫 Заблокированные пользователи:\n\n"
    
    if not banned_users:
        banned_text += "Нет заблокированных пользователей.\n"
    else:
        for i, (user_id, ban_data) in enumerate(banned_users.items(), 1):
            reason = ban_data.get("reason", "Причина не указана")
            date = ban_data.get("date", "")
            
            # Получаем информацию о пользователе
            user_data = users.get(user_id, {})
            username = user_data.get("username", "Нет имени")
            first_name = user_data.get("first_name", "")
            
            # Для безопасности удаляем символы Markdown из имени пользователя
            if username:
                username = username.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`")
            if first_name:
                first_name = first_name.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`")
            
            banned_text += f"{i}. {first_name} (@{username}) - {reason}\n"
    
    # Создаем кнопки разбана для каждого заблокированного пользователя
    keyboard = []
    for i, user_id in enumerate(list(banned_users.keys())[:5], 1):  # Только первые 5 пользователей
        keyboard.append([InlineKeyboardButton(f"Разбанить #{i}", callback_data=f"unban_user_{user_id}")])
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="admin_back")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.edit_text(
        banned_text,
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def ban_user(query, context, user_id):
    """Блокировка пользователя."""
    banned_users = load_banned_users()
    users = load_users()
    
    # Если пользователь уже заблокирован, то ничего не делаем
    if user_id in banned_users:
        await query.answer("Этот пользователь уже заблокирован", show_alert=True)
        return
    
    # Получаем информацию о пользователе
    user_data = users.get(user_id, {})
    username = user_data.get("username", "Нет имени")
    first_name = user_data.get("first_name", "")
    
    # Добавляем пользователя в список заблокированных
    banned_users[user_id] = {
        "reason": "Заблокирован администратором",
        "date": datetime.now().isoformat(),
        "admin_id": query.from_user.id
    }
    
    save_banned_users(banned_users)
    
    await query.answer(f"Пользователь {first_name} (@{username}) заблокирован", show_alert=True)
    
    # Возвращаемся к управлению блокировками
    await manage_bans(query, context)

async def unban_user(query, context, user_id):
    """Разблокировка пользователя."""
    banned_users = load_banned_users()
    users = load_users()
    
    # Если пользователь не заблокирован, то ничего не делаем
    if user_id not in banned_users:
        await query.answer("Этот пользователь не заблокирован", show_alert=True)
        return
    
    # Получаем информацию о пользователе
    user_data = users.get(user_id, {})
    username = user_data.get("username", "Нет имени")
    first_name = user_data.get("first_name", "")
    
    # Удаляем пользователя из списка заблокированных
    del banned_users[user_id]
    
    save_banned_users(banned_users)
    
    await query.answer(f"Пользователь {first_name} (@{username}) разблокирован", show_alert=True)
    
    # Возвращаемся к управлению блокировками
    await manage_bans(query, context)