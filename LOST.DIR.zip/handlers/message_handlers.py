import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import RESPONSES
from utils.helpers import detect_intent
from handlers.admin_handlers import update_user_data, is_user_banned
from handlers.command_handlers import activity_command, stat_command
from utils.monitoring import track_message

logger = logging.getLogger(__name__)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user messages and respond accordingly."""
    user = update.effective_user
    user_id = user.id
    username = user.username
    
    # Сохраняем/обновляем данные о пользователе в базе
    user_info = update_user_data(user)
    
    # Проверяем, не заблокирован ли пользователь
    if is_user_banned(user_id):
        logger.warning(f"Blocked message from banned user {user_id} ({username})")
        return
    
    # Получаем данные пользователя из контекста или создаем новые
    user_data = context.user_data
    if 'last_response_time' not in user_data:
        user_data['last_response_time'] = 0
    if 'message_count' not in user_data:
        user_data['message_count'] = 0
    
    # Увеличиваем счетчик сообщений пользователя
    user_data['message_count'] += 1
    
    # Отслеживаем каждое сообщение для статистики
    chat_id = update.effective_chat.id
    track_message(user_id, chat_id, is_command=False)
    
    # Проверяем, содержит ли сообщение текст
    if update.message.text:
        user_message = update.message.text
        logger.info(f"Received text message from {user_id} ({username}): {user_message}")
        
        # Обрабатываем текстовые команды с префиксом "."
        if user_message.startswith('.'):
            lower_message = user_message.lower()
            
            # Команда .стат - статистика пользователя
            if lower_message.startswith('.стат'):
                track_message(user_id, chat_id, is_command=True)
                await stat_command(update, context)
                return
            
            # Команда .актив - статистика активности и использования ресурсов
            elif lower_message.startswith('.актив'):
                track_message(user_id, chat_id, is_command=True)
                await activity_command(update, context)
                return
        
        # Проверяем, является ли сообщение прямым обращением к боту
        # или содержит ключевые слова, требующие ответа
        direct_address = any(keyword in user_message.lower() for keyword in ['бот', 'celestiana', 'целестиана'])
        
        # Detect user's intent from the message
        intent = detect_intent(user_message)
        
        # Решаем, отвечать ли на сообщение
        # Отвечаем, если:
        # 1. Сообщение содержит прямое обращение к боту
        # 2. Это первое сообщение пользователя
        # 3. Явно определен интент, требующий ответа
        should_respond = (
            direct_address or 
            user_data['message_count'] <= 1 or
            intent in ["greeting", "farewell", "thanks", "help"]
        )
        
        if should_respond:
            # Обновляем время последнего ответа
            user_data['last_response_time'] = update.message.date.timestamp()
            
            # Respond based on intent
            if intent == "greeting":
                keyboard = [
                    [
                        InlineKeyboardButton("Помощь", callback_data="help"),
                        InlineKeyboardButton("О боте", callback_data="about")
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await update.message.reply_text(
                    "Привет! Чем я могу помочь вам сегодня?", 
                    reply_markup=reply_markup
                )
            elif intent == "farewell":
                await update.message.reply_text("До свидания! Возвращайтесь когда захотите.")
            elif intent == "thanks":
                await update.message.reply_text("Пожалуйста! Есть ли что-то ещё, с чем я могу помочь?")
            elif intent == "help":
                await update.message.reply_text(RESPONSES["help"])
            elif direct_address:
                await update.message.reply_text(RESPONSES["unknown"])
        else:
            # Не отвечаем на сообщение, только логируем его
            logger.info(f"Skipping response to message from {user_id} (not direct address or required intent)")
    
    # Обработка сообщений с фотографиями - отвечаем только на фото с подписью
    elif update.message.photo:
        logger.info(f"Received photo from {user_id} ({username})")
        caption = update.message.caption
        
        # Отвечаем только если есть подпись к фото
        if caption:
            photo_file = await update.message.photo[-1].get_file()
            await update.message.reply_text(
                f"Я получил вашу фотографию! Подпись: {caption}"
            )
    
    # Обработка стикеров - проверяем атрибут sticker напрямую
    elif hasattr(update.message, 'sticker') and update.message.sticker:
        logger.info(f"Received sticker from {user_id} ({username})")
        
        # Получаем данные о стикерах пользователя
        if 'stickers_received' not in user_data:
            user_data['stickers_received'] = 0
        
        # Увеличиваем счетчик стикеров
        user_data['stickers_received'] += 1
        
        # Получаем эмодзи из стикера (если есть)
        sticker_emoji = getattr(update.message.sticker, 'emoji', None)
        
        # Отвечаем только на первый стикер или если стикер содержит определенный эмодзи
        if user_data['stickers_received'] <= 1 or (sticker_emoji and sticker_emoji in ['🤩', '😍', '👍', '❤️']):
            # Стикер с эмодзи, отвечаем соответствующим текстом
            if sticker_emoji == '🤩':
                await update.message.reply_text("Ого, какой классный стикер! 🤩")
            elif sticker_emoji == '😍':
                await update.message.reply_text("Мне тоже нравится этот стикер! 😍")
            elif sticker_emoji == '👍':
                await update.message.reply_text("Спасибо за одобрение! 👍")
            elif sticker_emoji == '❤️':
                await update.message.reply_text("И я вас тоже ❤️")
            else:
                await update.message.reply_text("Спасибо за стикер! 👍")
    
    # Обработка других типов сообщений - не отвечаем по умолчанию
    else:
        logger.info(f"Received unsupported message type from {user_id} ({username}) - no response sent")

async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик для inline кнопок."""
    query = update.callback_query
    
    # Уведомляем Telegram, что мы получили callback query
    await query.answer()
    
    # Перенаправляем административные callback-запросы в специальный обработчик
    if query.data.startswith("admin_"):
        from handlers.admin_handlers import handle_admin_callback
        await handle_admin_callback(update, context)
        return
    
    # Обрабатываем обновление статистики активности
    if query.data == "refresh_activity":
        from handlers.command_handlers import activity_command
        
        # Отслеживаем использование команды
        track_message(query.from_user.id, query.message.chat.id, is_command=True)
        
        # Обновляем статистику
        from utils.monitoring import format_activity_text
        from telegram.constants import ParseMode
        
        try:
            # Формируем новую статистику активности и использования ресурсов
            activity_text = format_activity_text()
            
            # Создаем клавиатуру с кнопкой "Обновить"
            keyboard = [
                [InlineKeyboardButton("🔄 Обновить", callback_data="refresh_activity")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Редактируем сообщение с новой статистикой
            await query.message.edit_text(
                activity_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            
            await query.answer("Статистика обновлена!")
        except Exception as e:
            logger.error(f"Error refreshing activity stats: {e}")
            await query.answer("Ошибка при обновлении статистики")
        return
    
    # Обрабатываем обычные callback-запросы
    if query.data == "help":
        await query.message.reply_text(RESPONSES["help"])
    elif query.data == "about":
        await query.message.reply_text(RESPONSES["about"])
    else:
        await query.message.reply_text("Неизвестная команда.")
