import logging
import random
import tempfile
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from config import RESPONSES
from handlers.admin_handlers import admin_command, is_admin, load_users
from utils.image_generator import create_profile_image
from utils.relationships import get_relationship_levels_info, get_user_profile
from utils.monitoring import format_activity_text, track_command

logger = logging.getLogger(__name__)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a welcome message when the command /start is issued."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) started the bot")
    
    await update.message.reply_text(
        f"Привет, {user.first_name}! {RESPONSES['welcome']}"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a help message when the command /help is issued."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) requested help")
    
    # Показываем разные варианты помощи для админов и обычных пользователей
    if is_admin(user.id):
        await update.message.reply_text(RESPONSES["help_admin"])
    else:
        await update.message.reply_text(RESPONSES["help"])

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send information about the bot when the command /about is issued."""
    logger.info(f"User {update.effective_user.id} requested about info")
    
    await update.message.reply_text(RESPONSES["about"])

async def random_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a random item when the command /random is issued."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) requested a random item")
    
    # Список случайных текстовых сообщений
    random_texts = [
        "Интересный факт: Медведи могут бегать со скоростью до 50 км/ч! 🐻",
        "Космический факт: Полный оборот вокруг Солнца Юпитер совершает за 12 земных лет. ♐",
        "Забавный факт: Фламинго могут спать стоя на одной ноге. 🦩",
        "Любопытный факт: Человеческий глаз способен различать до 10 миллионов цветов. 👁️",
        "Технический факт: Первый iPhone был выпущен в 2007 году. 📱",
        "Гастрономический факт: В мире существует более 1000 сортов сыра. 🧀",
        "Литературный факт: 'Война и мир' Льва Толстого содержит более 560 000 слов. 📚",
        "Биологический факт: У осьминогов три сердца. 🐙",
        "Географический факт: Самое глубокое озеро в мире - Байкал, его глубина около 1642 метров. 🌊",
        "Исторический факт: Сфинкс в Египте был построен более 4500 лет назад. 🏛️"
    ]
    
    # URL случайных картинок
    random_images = [
        "https://cdn.pixabay.com/photo/2020/02/03/05/37/landscape-4815143_960_720.jpg",
        "https://cdn.pixabay.com/photo/2016/05/05/02/37/sunset-1373171_960_720.jpg",
        "https://cdn.pixabay.com/photo/2019/12/15/08/15/sunset-4696822_960_720.jpg",
        "https://cdn.pixabay.com/photo/2020/01/14/18/23/winter-4766625_960_720.jpg",
        "https://cdn.pixabay.com/photo/2015/11/16/16/28/bird-1045954_960_720.jpg"
    ]
    
    # Выбираем, что отправлять: текст или картинку
    if random.choice([True, False]):
        # Отправляем случайный текст
        await update.message.reply_text(random.choice(random_texts))
    else:
        # Отправляем случайную картинку
        await update.message.reply_photo(
            photo=random.choice(random_images),
            caption="Вот случайная картинка для вас! 🌟"
        )

async def weather_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Provide a simple weather forecast joke."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) requested weather")
    
    weather_options = [
        "Сегодня на улице отличная погода для общения с ботом! 🌞",
        "Прогноз погоды: ожидается высокая вероятность хорошего настроения! ⛅",
        "Погода сегодня: виртуально-солнечная, с небольшими осадками в виде сообщений! 🌦️",
        "Метеорологи предсказывают благоприятные условия для чатов и мемов! 📱",
        "Сегодня без осадков, но возможен шторм стикеров в чате! 🌪️",
        "Температура онлайн-общения сегодня повышенная, не забудьте про эмодзи! 😎"
    ]
    
    await update.message.reply_text(random.choice(weather_options))
    
async def admin_panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать административную панель управления."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) requested admin panel")
    
    # Проверяем, является ли пользователь администратором
    if not is_admin(user.id):
        logger.warning(f"Unauthorized admin access attempt by {user.id} ({user.username})")
        await update.message.reply_text(RESPONSES["admin_not_allowed"])
        return
    
    # Если пользователь администратор, вызываем функцию для отображения панели
    await admin_command(update, context)

async def stat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать статистику пользователя с изображением."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) requested stats image")
    
    # Отслеживаем использование команды
    track_command("stat", user.id)
    
    # Отправляем сообщение о генерации статистики
    status_message = await update.message.reply_text(
        "⏳ Генерирую вашу персональную статистику..."
    )
    
    try:
        # Генерируем изображение с профилем пользователя
        users_data = load_users()
        image_bytes = create_profile_image(user, users_data)
        
        # Сохраняем изображение во временный файл
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as temp_file:
            temp_file.write(image_bytes)
            temp_file_path = temp_file.name
        
        # Отправляем изображение с основной статистикой
        with open(temp_file_path, 'rb') as photo:
            await update.message.reply_photo(
                photo=photo,
                caption=f"📊 Персональная статистика пользователя @{user.username or user.first_name}"
            )
        
        # Удаляем временный файл
        os.unlink(temp_file_path)
        
        # Удаляем сообщение о генерации
        await status_message.delete()
        
    except Exception as e:
        logger.error(f"Error generating stats image: {e}")
        await status_message.edit_text(
            f"⚠️ Произошла ошибка при генерации статистики: {str(e)[:100]}..."
        )

async def activity_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать статистику использования ресурсов бота."""
    user = update.effective_user
    logger.info(f"User {user.id} ({user.username}) requested activity stats")
    
    # Отслеживаем использование команды
    track_command("activity", user.id)
    
    # Отправляем сообщение о генерации статистики
    status_message = await update.message.reply_text(
        "⏳ Собираю данные о системных ресурсах..."
    )
    
    try:
        # Формируем статистику активности и использования ресурсов
        activity_text = format_activity_text()
        
        # Создаем клавиатуру с кнопкой "Обновить"
        keyboard = [
            [InlineKeyboardButton("🔄 Обновить", callback_data="refresh_activity")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Отправляем статистику с кнопкой
        await update.message.reply_text(
            activity_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
        
        # Удаляем сообщение о генерации
        await status_message.delete()
    except Exception as e:
        logger.error(f"Error generating activity stats: {e}")
        await status_message.edit_text(
            f"⚠️ Произошла ошибка при сборе статистики: {str(e)[:100]}..."
        )
