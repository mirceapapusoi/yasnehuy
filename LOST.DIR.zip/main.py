import logging
import os
import threading
import json
import datetime
from flask import Flask, render_template, jsonify, redirect, url_for
from bot import run_bot
from models import db, User, Chat, Message, CommandStat, Relationship, ActivityStat
from utils.monitoring import load_monitoring_data, get_system_stats, format_activity_text

# Setup logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.DEBUG
)
logger = logging.getLogger(__name__)

# Создание Flask приложения
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "celestiana_secret_key")

# Конфигурация базы данных
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Инициализация базы данных
db.init_app(app)

# Создание таблиц при запуске
with app.app_context():
    try:
        # Проверяем, существуют ли уже таблицы в базе данных
        from sqlalchemy import inspect
        inspector = inspect(db.engine)
        tables = inspector.get_table_names()
        if not tables:
            logger.info("Создание таблиц в базе данных...")
            db.create_all()
        else:
            logger.info(f"Таблицы уже существуют: {tables}")
    except Exception as e:
        logger.error(f"Ошибка при инициализации базы данных: {e}")

# Создаем папку для шаблонов, если её нет
if not os.path.exists("templates"):
    os.makedirs("templates")

# Создаем простой шаблон для веб-интерфейса
with open("templates/index.html", "w") as f:
    f.write("""
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ясен Хуй Bot - Статистика</title>
    <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
    <style>
        body {
            padding-top: 20px;
        }
        .refresh-btn {
            margin-top: 20px;
        }
        .stats-card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container" data-bs-theme="dark">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center mb-4">Ясен Хуй Bot - Панель мониторинга</h1>
                
                <div class="card stats-card">
                    <div class="card-header">
                        <h4>Общая статистика</h4>
                    </div>
                    <div class="card-body">
                        <div id="general-stats">Загрузка данных...</div>
                    </div>
                </div>
                
                <div class="card stats-card">
                    <div class="card-header">
                        <h4>Системные ресурсы</h4>
                    </div>
                    <div class="card-body">
                        <div id="system-stats">Загрузка данных...</div>
                    </div>
                </div>
                
                <div class="card stats-card">
                    <div class="card-header">
                        <h4>Популярные команды</h4>
                    </div>
                    <div class="card-body">
                        <div id="commands-stats">Загрузка данных...</div>
                    </div>
                </div>
                
                <div class="text-center refresh-btn">
                    <button id="refresh-btn" class="btn btn-primary">Обновить статистику</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function formatStats(stats) {
            let uptime = stats.uptime;
            let uptimeStr = `${uptime.days}д ${uptime.hours}ч ${uptime.minutes}м ${uptime.seconds}с`;
            
            let html = `
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Время работы: ${uptimeStr}</li>
                            <li class="list-group-item">Всего пользователей: ${stats.users_count}</li>
                            <li class="list-group-item">Всего чатов: ${stats.chats_count}</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Обработано сообщений: ${stats.messages_processed}</li>
                            <li class="list-group-item">Выполнено команд: ${stats.commands_executed}</li>
                            <li class="list-group-item">Ошибок: ${stats.errors_count}</li>
                        </ul>
                    </div>
                </div>

                <h5 class="mt-3">Сегодня:</h5>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Сообщений: ${stats.today_stats.messages}</li>
                    <li class="list-group-item">Команд: ${stats.today_stats.commands}</li>
                    <li class="list-group-item">Активных пользователей: ${stats.today_stats.users}</li>
                </ul>
            `;
            
            return html;
        }

        function formatSystemStats(stats) {
            let html = `
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">CPU: ${stats.cpu_percent}% (системный: ${stats.system_cpu_percent}%)</li>
                            <li class="list-group-item">RAM: ${stats.memory_usage_mb} MB</li>
                            <li class="list-group-item">Потоков: ${stats.threads_count}</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Системная память: ${stats.system_memory_percent}%</li>
                            <li class="list-group-item">Пиковое использование CPU: ${stats.peak_cpu_usage}%</li>
                            <li class="list-group-item">Пиковое использование RAM: ${stats.peak_memory_usage} MB</li>
                        </ul>
                    </div>
                </div>
            `;
            
            return html;
        }

        function formatCommandsStats(commands) {
            if (!commands || commands.length === 0) {
                return '<p>Нет данных о командах</p>';
            }
            
            let html = '<ul class="list-group list-group-flush">';
            
            commands.forEach((cmd, index) => {
                html += `<li class="list-group-item">${index + 1}. ${cmd[0]}: ${cmd[1].count} раз</li>`;
            });
            
            html += '</ul>';
            
            return html;
        }

        function fetchStats() {
            fetch('/api/stats')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('general-stats').innerHTML = formatStats(data);
                    document.getElementById('system-stats').innerHTML = formatSystemStats(data);
                    document.getElementById('commands-stats').innerHTML = formatCommandsStats(data.top_commands);
                })
                .catch(error => {
                    console.error('Ошибка при получении статистики:', error);
                });
        }

        // Загрузка статистики при загрузке страницы
        document.addEventListener('DOMContentLoaded', fetchStats);

        // Обновление статистики по кнопке
        document.getElementById('refresh-btn').addEventListener('click', fetchStats);

        // Автоматическое обновление каждые 30 секунд
        setInterval(fetchStats, 30000);
    </script>
</body>
</html>
    """)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/db/users')
def get_db_users():
    """Отдает список пользователей из базы данных."""
    try:
        users = User.query.order_by(User.messages_count.desc()).limit(20).all()
        user_list = []
        
        for user in users:
            user_data = {
                "id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "messages_count": user.messages_count,
                "commands_count": user.commands_count,
                "is_admin": user.is_admin,
                "is_banned": user.is_banned,
                "created_at": user.created_at.isoformat() if user.created_at else None
            }
            user_list.append(user_data)
        
        return jsonify({"count": len(user_list), "users": user_list})
    except Exception as e:
        logger.error(f"Ошибка при получении пользователей из БД: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/db/chats')
def get_db_chats():
    """Отдает список чатов из базы данных."""
    try:
        chats = Chat.query.order_by(Chat.messages_count.desc()).limit(20).all()
        chat_list = []
        
        for chat in chats:
            chat_data = {
                "id": chat.id,
                "title": chat.title,
                "type": chat.type,
                "username": chat.username,
                "messages_count": chat.messages_count,
                "commands_count": chat.commands_count,
                "created_at": chat.created_at.isoformat() if chat.created_at else None
            }
            chat_list.append(chat_data)
        
        return jsonify({"count": len(chat_list), "chats": chat_list})
    except Exception as e:
        logger.error(f"Ошибка при получении чатов из БД: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/db/relationships')
def get_db_relationships():
    """Отдает список отношений из базы данных."""
    try:
        relationships = Relationship.query.filter_by(status="active").order_by(Relationship.level.desc()).limit(20).all()
        rel_list = []
        
        for rel in relationships:
            rel_data = {
                "id": rel.id,
                "from_user_id": rel.from_user_id,
                "to_user_id": rel.to_user_id,
                "from_user": rel.from_user.username or rel.from_user.first_name,
                "to_user": rel.to_user.username or rel.to_user.first_name,
                "chat_id": rel.chat_id,
                "status": rel.status,
                "level": rel.level,
                "experience": rel.experience,
                "is_offended": rel.is_offended,
                "created_at": rel.created_at.isoformat() if rel.created_at else None,
                "activated_at": rel.activated_at.isoformat() if rel.activated_at else None
            }
            rel_list.append(rel_data)
        
        return jsonify({"count": len(rel_list), "relationships": rel_list})
    except Exception as e:
        logger.error(f"Ошибка при получении отношений из БД: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/db/commands')
def get_db_commands():
    """Отдает статистику команд из базы данных."""
    try:
        commands = CommandStat.query.order_by(CommandStat.count.desc()).limit(20).all()
        cmd_list = []
        
        for cmd in commands:
            cmd_data = {
                "id": cmd.id,
                "command_name": cmd.command_name,
                "user_id": cmd.user_id,
                "username": cmd.user.username or cmd.user.first_name if cmd.user else "Unknown",
                "count": cmd.count,
                "last_used": cmd.last_used.isoformat() if cmd.last_used else None
            }
            cmd_list.append(cmd_data)
        
        return jsonify({"count": len(cmd_list), "commands": cmd_list})
    except Exception as e:
        logger.error(f"Ошибка при получении статистики команд из БД: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/db/messages')
def get_db_messages():
    """Отдает последние сообщения из базы данных."""
    try:
        messages = Message.query.order_by(Message.created_at.desc()).limit(20).all()
        msg_list = []
        
        for msg in messages:
            # Обрезаем текст для безопасности и краткости
            text = msg.text[:100] + "..." if msg.text and len(msg.text) > 100 else msg.text
            
            msg_data = {
                "id": msg.id,
                "message_id": msg.message_id,
                "user_id": msg.user_id,
                "username": msg.user.username or msg.user.first_name if msg.user else "Unknown",
                "chat_id": msg.chat_id,
                "chat_title": msg.chat.title if msg.chat else "Unknown",
                "text": text,
                "is_command": msg.is_command,
                "sentiment": msg.sentiment,
                "created_at": msg.created_at.isoformat() if msg.created_at else None
            }
            msg_list.append(msg_data)
        
        return jsonify({"count": len(msg_list), "messages": msg_list})
    except Exception as e:
        logger.error(f"Ошибка при получении сообщений из БД: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/stats')
def get_stats():
    """Отдает статистику работы бота в формате JSON."""
    try:
        # Создаем данные по умолчанию, если файл мониторинга не существует
        if not os.path.exists("data/monitoring.json"):
            default_data = {
                "start_time": datetime.datetime.now().isoformat(),
                "commands_executed": 0,
                "messages_processed": 0,
                "users_count": 0,
                "chats_count": 0,
                "errors_count": 0,
                "peak_memory_usage": 0,
                "peak_cpu_usage": 0,
                "daily_stats": {},
                "hourly_stats": {},
                "today_stats": {"messages": 0, "commands": 0, "users": 0},
                "uptime": {"days": 0, "hours": 0, "minutes": 0, "seconds": 0}
            }
            
            # Добавляем системную статистику
            system_stats = get_system_stats()
            for key, value in system_stats.items():
                default_data[key] = value
                
            # Временно используем пустые топ-команды
            default_data["top_commands"] = []
            
            return jsonify(default_data)
        
        # Если файлы существуют, получаем реальные данные
        monitoring_data = load_monitoring_data()
        
        # Форматируем время работы
        now = datetime.datetime.now()
        start_time = datetime.datetime.fromisoformat(monitoring_data["start_time"]) if monitoring_data["start_time"] else now
        uptime = now - start_time
        uptime_days = uptime.days
        uptime_hours, remainder = divmod(uptime.seconds, 3600)
        uptime_minutes, uptime_seconds = divmod(remainder, 60)
        
        monitoring_data["uptime"] = {
            "days": uptime_days,
            "hours": uptime_hours,
            "minutes": uptime_minutes,
            "seconds": uptime_seconds
        }
        
        # Статистика за сегодня
        day_key = now.strftime("%Y-%m-%d")
        
        monitoring_data["today_stats"] = {
            "messages": monitoring_data["daily_stats"].get(day_key, {}).get("messages", 0),
            "commands": monitoring_data["daily_stats"].get(day_key, {}).get("commands", 0),
            "users": len(monitoring_data["daily_stats"].get(day_key, {}).get("users", []))
        }
        
        # Добавляем системную статистику
        system_stats = get_system_stats()
        for key, value in system_stats.items():
            monitoring_data[key] = value
        
        # Загружаем статистику команд
        try:
            if os.path.exists("data/commands_stats.json"):
                with open("data/commands_stats.json", "r", encoding="utf-8") as f:
                    command_stats = json.load(f)
                    
                # Получаем топ-5 самых используемых команд
                top_commands = sorted(
                    command_stats.items(),
                    key=lambda x: x[1]["count"],
                    reverse=True
                )[:5]
                
                monitoring_data["top_commands"] = top_commands
            else:
                monitoring_data["top_commands"] = []
        except Exception as e:
            logger.error(f"Ошибка при загрузке статистики команд: {e}")
            monitoring_data["top_commands"] = []
        
        # Округляем числовые значения
        for key in ["peak_memory_usage", "peak_cpu_usage", "cpu_percent", "memory_usage_mb"]:
            if key in monitoring_data and isinstance(monitoring_data[key], (int, float)):
                monitoring_data[key] = round(monitoring_data[key], 2)
        
        return jsonify(monitoring_data)
    except Exception as e:
        logger.error(f"Ошибка при получении статистики: {e}")
        return jsonify({
            "error": str(e),
            "start_time": datetime.datetime.now().isoformat(),
            "commands_executed": 0,
            "messages_processed": 0,
            "users_count": 0,
            "chats_count": 0,
            "errors_count": 0,
            "peak_memory_usage": 0,
            "peak_cpu_usage": 0,
            "cpu_percent": 0,
            "system_cpu_percent": 0,
            "memory_usage_mb": 0,
            "system_memory_percent": 0,
            "system_memory_total_gb": 0,
            "system_memory_available_gb": 0,
            "threads_count": 0,
            "uptime_seconds": 0,
            "today_stats": {"messages": 0, "commands": 0, "users": 0},
            "uptime": {"days": 0, "hours": 0, "minutes": 0, "seconds": 0},
            "top_commands": []
        })

# Для Flask приложения мы не будем запускать бота в потоке,
# чтобы не конфликтовать с основным воркфлоу, который запускает бота
# Вместо этого мы будем просто показывать статистику из файлов и базы данных

# Создаем функцию для мониторинга и обновления статистики активности бота
def update_activity_stats():
    """Обновляет статистику активности бота в базе данных."""
    try:
        from datetime import date, datetime
        import psutil
        from models import ActivityStat
        
        # Получаем текущую дату и час
        today = date.today()
        current_hour = datetime.now().hour
        
        # Находим запись для текущего часа или создаем новую
        with app.app_context():
            activity = ActivityStat.query.filter_by(date=today, hour=current_hour).first()
            if not activity:
                activity = ActivityStat(date=today, hour=current_hour)
                db.session.add(activity)
            
            # Обновляем данные о системных ресурсах
            process = psutil.Process(os.getpid())
            activity.cpu_usage = process.cpu_percent()
            activity.memory_usage = process.memory_info().rss / 1024 / 1024  # MB
            
            # Сохраняем изменения
            db.session.commit()
            
            logger.info(f"Обновлена статистика активности для {today} {current_hour}:00")
    except Exception as e:
        logger.error(f"Ошибка при обновлении статистики активности: {e}")

# Запускаем обновление статистики активности по расписанию
def start_scheduler():
    """Запускает планировщик для регулярного обновления статистики."""
    import threading
    import time
    
    def scheduler():
        while True:
            update_activity_stats()
            time.sleep(900)  # Обновляем каждые 15 минут
    
    # Запускаем планировщик в отдельном потоке
    scheduler_thread = threading.Thread(target=scheduler, daemon=True)
    scheduler_thread.start()

if __name__ == "__main__":
    # Запуск планировщика обновления статистики
    start_scheduler()
    
    # Запуск веб-сервера Flask (для бота используем другой порт)
    app.run(host="0.0.0.0", port=5000, debug=True)
