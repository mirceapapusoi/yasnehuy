import os
import logging
from dotenv import load_dotenv

# Загрузка переменных окружения из .env файла (если существует)
load_dotenv()

# Bot token from environment variables
BOT_TOKEN = os.getenv("BOT_TOKEN", "7632023422:AAFvrAScl0hO_Cq0bbvMWeMUJKuxjuWUSME")

# Configure logging
logger = logging.getLogger(__name__)

# Bot configuration
BOT_NAME = "Ясен Хуй"
BOT_USERNAME = "celestiana_bot"  # Не меняем юзернейм для сохранения работоспособности
BOT_DESCRIPTION = "A magical assistant bot"

# Директория для хранения данных
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

# ID администраторов (строки, а не числа)
# Укажите ID администраторов здесь
# Для добавления нескольких админов, разделите их запятыми в .env файле
ADMIN_IDS = os.getenv("ADMIN_IDS", "1336991712").split(",")

# Command descriptions for BotFather
COMMANDS = {
    "start": "Start the bot and get a welcome message",
    "help": "Get help on how to use the bot",
    "about": "Learn about the bot",
    "random": "Get a random fact or image",
    "weather": "Get a funny weather forecast",
    "feedback": "Send feedback to the developers",
    "admin": "Access admin control panel (admin only)"
}

# Bot responses
RESPONSES = {
    "welcome": "✨ Добро пожаловать в Celestiana! Я ваш волшебный помощник. Чем я могу вам помочь сегодня?",
    "help": "Вот команды, которые вы можете использовать:\n"
            "/start - Запустить бота\n"
            "/help - Показать это справочное сообщение\n"
            "/about - Узнать о боте\n"
            "/random - Получить случайный факт или картинку\n"
            "/weather - Узнать прогноз погоды (с юмором)\n"
            "/feedback - Отправить отзыв разработчикам",
    "help_admin": "Вот команды, которые вы можете использовать:\n"
            "/start - Запустить бота\n"
            "/help - Показать это справочное сообщение\n"
            "/about - Узнать о боте\n"
            "/random - Получить случайный факт или картинку\n"
            "/weather - Узнать прогноз погоды (с юмором)\n"
            "/feedback - Отправить отзыв разработчикам\n"
            "/admin - Панель администратора",
    "about": f"{BOT_NAME} - это волшебный бот-помощник, созданный для помощи вам с различными задачами. Я могу отвечать на ваши сообщения, отправлять интересные факты и изображения, и даже шутить о погоде!",
    "unknown": "Я не уверен, как ответить на это. Попробуйте /help, чтобы увидеть, что я могу делать.",
    "feedback_start": "Я бы хотел услышать ваш отзыв! Пожалуйста, напишите ваше сообщение ниже:",
    "feedback_received": "Спасибо за ваш отзыв! Он был записан.",
    "feedback_cancel": "Отзыв отменен.",
    "admin_not_allowed": "У вас нет прав для использования этой команды.",
}
